/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_ACL_RM_TYPES_H__
#define __SX_ACL_RM_TYPES_H__

#include <sx/sdk/sx_types.h>


/************************************************
 *  Definitions
 ***********************************************/

#define ACL_RM_ACL_INFO_CLR(acl_info)               \
    ;                                               \
    acl_info.acl_id = 0;                            \
    acl_info.acl_key_type = SX_ACL_KEY_TYPE_LAST;   \
    acl_info.action_type = SX_ACL_ACTION_TYPE_LAST; \
    acl_info.acl_type = SX_ACL_TYPE_LAST;           \
    acl_info.acl_direction = SX_ACL_DIRECTION_MAX;  \
    acl_info.min_acl_size = 0;                      \
    acl_info.max_acl_size = 0;

#define ACL_RM_CHECK_FAIL(STATUS) (SX_ACL_RM_STATUS_SUCCESS != (STATUS))

#define SX_ACL_RM_ACL_TABLE_INF_SIZE (0)
#define SX_ACL_RM_MAX_PORT_BIND      100
#define SX_ACL_RM_MAX_MC_PORT        SX_ACL_RM_MAX_PORT_BIND

#define SX_ACL_RM_MAX_COUNTER_BIND_RULES 100

#define SX_ACL_RM_COUNTER_NUM        255
#define SX_ACL_RM_COUNTER_ID_INVALID SX_FLOW_COUNTER_ID_INVALID
#define SX_ACL_RM_COUNTER_ID_FREE    SX_ACL_RM_COUNTER_ID_INVALID


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * describes the action on the activity bit
 */
typedef uint64_t sx_acl_rm_handle_t;

/**
 * sx_acl_rm_client_t enumerated type is used to note the owner of the handle towards ACL-RM
 * used for open RPC connection.
 */
typedef enum sx_acl_rm_client {
    OPEN_FLOW_CLIENT = 0,
    MLNX_OS_CLIENT,
    PRA_CLIENT,
    OPEN_FLOW_13_CLIENT,
    MAX_ACL_RM_CLIENT,
} sx_acl_rm_client_t;

/**
 * sx_acl_rm_status_t enumerated type is used to
 */
typedef enum sx_acl_rm_status {
    SX_ACL_RM_STATUS_SUCCESS = 0,
    SX_ACL_RM_STATUS_ERROR,
    SX_ACL_RM_STATUS_CMD_UNSUPPORTED,
    SX_ACL_RM_STATUS_PARAM_NULL,
    SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE,
    SX_ACL_RM_STATUS_ENTRY_NOT_FOUND,
    SX_ACL_RM_STATUS_NO_RESOURCES,
    SX_ACL_RM_STATUS_NO_HW_RESOURCES,
    SX_ACL_RM_STATUS_NO_BUFFER_SPACE,
    SX_ACL_RM_STATUS_LAST
} sx_acl_rm_status_t;

static __attribute__((__used__)) const char *acl_rm_string_errors[] = {
    "SX_ACL_RM_STATUS_SUCCESS",
    "SX_ACL_RM_STATUS_ERROR",
    "SX_ACL_RM_STATUS_CMD_UNSUPPORTED",
    "SX_ACL_RM_STATUS_PARAM_NULL",
    "SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE",
    "SX_ACL_RM_STATUS_ENTRY_NOT_FOUND",
    "SX_ACL_RM_STATUS_NO_RESOURCES",
    "SX_ACL_RM_STATUS_NO_HW_RESOURCES",
    "SX_ACL_RM_STATUS_NO_BUFFER_SPACE",
    "SX_ACL_RM_STATUS_LAST"
};

/**
 * sx_acl_rm_cmd_t enumerated type is used to note command action
 * used when calling ACL-RM API[s]
 */
typedef enum sx_acl_rm_cmd_t {
    SX_ACL_RM_CMD_NONE = 0,
    SX_ACL_RM_CMD_ADD,
    SX_ACL_RM_CMD_EDIT,
    SX_ACL_RM_CMD_DELETE,
    SX_ACL_RM_CMD_CREATE,
    SX_ACL_RM_CMD_DESTROY,
    SX_ACL_RM_CMD_SET,
    SX_ACL_RM_CMD_BIND,
    SX_ACL_RM_CMD_UNBIND,
    SX_ACL_RM_CMD_ADD_PORTS,
    SX_ACL_RM_CMD_DELETE_PORTS,
    SX_ACL_RM_CMD_GET_ALL,
    SX_ACL_RM_CMD_GET_MINE,
    SX_ACL_RM_CMD_READ,
    SX_ACL_RM_CMD_READ_AND_CLEAR,
    SX_ACL_RM_CMD_CLEAR,
} sx_acl_rm_cmd_t;


/**
 * sx_acl_rm_port_t type is used to note logical port.
 */
typedef sx_port_log_id_t sx_acl_rm_port_t;

/**
 * sx_acl_rm_key_type_t type is used to
 */
typedef sx_acl_key_type_t sx_acl_rm_key_type_t;

/**
 * acl_rm_action_type_t type is used to
 */
typedef sx_acl_action_type_t sx_acl_rm_action_type_t;

/**
 * sx_acl_rm_acl_type_t type is used to
 */
typedef sx_acl_type_t sx_acl_rm_acl_type_t;

/**
 * sx_acl_rm_acl_direction_t type is used to
 */
typedef sx_acl_direction_t sx_acl_rm_acl_direction_t;

/**
 * sx_acl_rm_acl_id_t type is used to
 */
typedef sx_acl_id_t sx_acl_rm_acl_id_t;

/**
 * sx_acl_rm_region_id_t type is used to
 */
typedef sx_acl_region_id_t sx_acl_rm_region_id_t;

/**
 * acl_rm_rule_offset_t type is used to
 */
typedef sx_acl_rule_offset_t sx_acl_rm_rule_offset_t;

/**
 * sx_acl_rm_rule_priority_t type is used to indicate rule's
 * priority
 */
typedef uint32_t sx_acl_rm_rule_priority_t;

/**
 * sx_acl_rm_rule_handle_t type is an opaque variable and is
 * used as an unique rule identifier.
 */
typedef uint32_t sx_acl_rm_rule_handle_t;


/**
 * sx_acl_activity_op_t enumerated type is used to note
 * an operation on the ACL Activity
 */
typedef enum {
    SX_ACL_RM_ACTIVITY_OP_NOP = 0,                    /**< No action is done */
    SX_ACL_RM_ACTIVITY_OP_READ = 1,                   /**< Read ACL Activity from HW  */
    SX_ACL_RM_ACTIVITY_OP_READ_AND_CLR = 2            /**< Read and Clear ACL Activity */
} sx_acl_rm_activity_op_t;

/**
 * sx_acl_activity_t struct type is used to control the ACL Activity
 */
typedef struct {
    sx_acl_rm_activity_op_t op;         /**<  operation to perform */
    uint8_t                 value;   /**<  Activity value (incase of read op)  */
} sx_acl_rm_activity_t;

/**
 * sx_acl_rm_fwd_action_type_t type is used to state forward
 * action entry type
 */
typedef enum sx_acl_rm_fwd_action_type {
    ACL_RM_FWD_ACTION_NONE,
    ACL_RM_FWD_ACTION_UNICAST,
    ACL_RM_FWD_ACTION_MULTICAST,
    ACL_RM_FWD_ACTION_FCF
} sx_acl_rm_fwd_action_type_t;


/**
 * sx_acl_rm_mcg_id_t type is used to
 */
typedef uint32_t sx_acl_rm_mcg_id_t;

/**
 * sx_acl_rm_rule_action_t structure is used to note the action of a rule
 */
typedef struct sx_acl_rm_rule_action {
    sx_acl_trap_action_t      trap_action;          /**< trap action  */
    uint16_t                  vlan_map_id;          /**< VLAN to be used in accordance with vlan_prio_action  */
    uint8_t                   priority;             /**< priority to be used in accordance with vlan_prio_action  */
    sx_acl_vlan_prio_action_t vlan_prio_action;     /**< Operation to perform on VLAN, priority and TClass  */
} sx_acl_rm_rule_action_t;

typedef struct sx_acl_rm_rule {
    sx_acl_rm_rule_priority_t priority;        /**<  rule's priority */
    sx_acl_rm_rule_handle_t   rule_handle;   /**<  rule handle is a unique value used for rule identification*/
    uint8_t                   valid;    /**<  rule activated in HW  */
    sx_acl_rule_key_t         key;      /**<  Key type and fields used for this rule  */
    sx_acl_rule_key_t         mask;     /**<  Masking of fields in the key for this rule  */
    sx_acl_action_set_t       action;   /**<  Action set used for this rule  */
    sx_acl_rm_activity_t      activity; /**<  Activity Operation to perform  */
} sx_acl_rm_rule_t;

/**
 * sx_acl_rm_forward_action_entry_t structure is used to describes forwarding entry
 */
typedef struct sx_acl_rm_forward_action_entry {
    sx_acl_rm_fwd_action_type_t fwd_action;                 /**< Indicates record type (forwarding data is taken according to this type) */
    sx_acl_rm_port_t            forwarding_log_port;            /**< Port ID, indicates the destination unicast port  */
    sx_acl_rm_mcg_id_t          mc_group;                   /**< Indicates the destination multicast group */
} sx_acl_rm_forward_action_entry_t;

/**
 * describes Flow counter value
 */
typedef sx_flow_counter_val_t sx_acl_rm_cntr_t;

/**
 * describes Flow counter id
 */
typedef sx_flow_counter_id_t sx_acl_rm_counter_id_t;

/**
 * sx_acl_rm_rule_info_t structure is used to note rule info
 */
typedef struct sx_acl_rm_rule_info {
    sx_acl_rm_rule_t                 acl_rule;          /**< a struct which describe the rule's properties */
    sx_acl_rm_forward_action_entry_t forward_action;    /**< a struct which describe the rule's forwarding action */
    sx_acl_rm_counter_id_t           counter_id;        /**< a struct which describe the rule's counter */
} sx_acl_rm_rule_info_t;


#define CLR_SX_ACL_RM_RULE_INFO(rule_info)       \
    memset(&rule_info, 0, sizeof(rule_info));    \
    CLR_SX_ACL_RULE_KEY(0, rule_info.acl_rule);  \
    CLR_SX_ACL_RULE_MASK(0, rule_info.acl_rule); \
    CLR_SX_ACL_RULE_ACTION(rule_info.acl_rule);  \
    rule_info.counter_id = SX_ACL_RM_COUNTER_ID_INVALID;

/**
 * describes Policy based switching entry
 */
typedef sx_acl_pbs_entry_t sx_acl_rm_pbs_entry;

/**
 * sx_acl_rm_acl_info_t structure is used to note acl info
 */
typedef struct sx_acl_rm_acl_info {
    sx_acl_rm_acl_id_t        acl_id;               /**< the i.d of the ACL given by ACL-RM */
    sx_acl_rm_key_type_t      acl_key_type;         /**< acl_rm_key_type_t i.e ipv4/ipv6/mac/...*/
    sx_acl_rm_action_type_t   action_type;          /**< acl_rm_action_type_t i.e default/extended */
    sx_acl_rm_acl_type_t      acl_type;             /**< acl_rm_acl_type i.e ALL or L3 */
    sx_acl_rm_acl_direction_t acl_direction;        /**< acl_rm_acl_direction i.e ingress/egress*/
    uint32_t                  min_acl_size;         /**< the minimum #rules reserved for this acl - best effort */
    uint32_t                  max_acl_size;         /**< the maximum #rules user can add to this acl */
    sx_acl_rm_region_id_t     region_id;
} sx_acl_rm_acl_info_t;


/**
 * sx_acl_rm_counter_type_t structure is used to note the counter type.
 */
typedef struct sx_acl_rm_counter_type {
    boolean_t bytes;
    boolean_t packets;
} sx_acl_rm_counter_type_t;

/**
 * sx_acl_rm_counter_value_t structure is used to note counter values according to counter type.
 */
typedef struct sx_acl_rm_counter_value {
    sx_acl_rm_cntr_t bytes;
    sx_acl_rm_cntr_t packets;
} sx_acl_rm_counter_value_t;

/**
 * sx_acl_rm_init_params_t structure is used to store various SwitchX
 * ACL RM init parameters.
 */
typedef struct sx_acl_rm_init_params {
    sxd_chip_types_t chip_type;
} sx_acl_rm_init_params_t;

#endif /* __SX_ACL_RM_TYPES_H__ */
