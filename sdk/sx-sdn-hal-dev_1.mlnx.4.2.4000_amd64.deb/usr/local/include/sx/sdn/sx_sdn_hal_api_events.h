/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_API_EVENTS_H__
#define __SX_SDN_HAL_API_EVENTS_H__

#include <sx/sdn/sx_sdn_hal_types.h>

/**
 * This function returns the file descriptor used for receiving events
 *
 * @param[out]    fd            - file descriptor
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_open(sx_sdn_hal_fd_t *fd);

/**
 * This function closes the file descriptor of the current open channel
 *
 * @param[in]    fd            - file descriptor
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_close(sx_sdn_hal_fd_t *fd);

/**
 * Register on events.
 *
 * @param[in]    fd            - file descriptor
 * @param[in]    event         - event to register to
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_event_register(sx_sdn_hal_fd_t   *fd,
                                                   sx_sdn_hal_event_t event);

/**
 * Unregister from events.
 *
 * @param[in]    fd            - file descriptor
 * @param[in]    event         - event to unregister from
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_SDN_HAL_STATUS_ERROR general error
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_event_unregister(sx_sdn_hal_fd_t   *fd,
                                                     sx_sdn_hal_event_t event);

/**
 * Send a unicast control packet through a specific logical port.Routing and QOS
 * from TX header.
 *
 * @param[in] fd			- File descriptor to send from.
 * @param[in] packet                    - buffer containing the packet to send.
 * @param[in] packet_size		- size of packet.
 * @param[in] egress_port	        - logical port of packet destination.
 * @param[in] prio			- priority of the packet.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 * @return SX_SDN_HAL_STATUS_NO_RESOURCES device was not opened
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_packet_send(sx_sdn_hal_fd_t      *fd,
                                                void                 *packet,
                                                uint32_t              packet_size,
                                                sx_sdn_hal_port_t     egress_port,
                                                sx_sdn_hal_priority_t prio);


/**
 * This API enables the user to perform select operation.
 *
 *@param[in]	fds		- File descriptors to run select on.
 *@param[in]	fds_count	- Size of fds array.
 *@param[in]	timeout		- timeout to return.
 *@param[out]	out_fds		- bitmap that indicates which FDs returned something.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 * @return SX_SDN_HAL_STATUS_NO_RESOURCES device was not opened
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_select(sx_sdn_hal_fd_t **fds,
                                           int               fds_count,
                                           struct timeval   *timeout,
                                           uint32_t         *out_fds);

/**
 * This API enables the user to receive Events.
 *
 *@param[in]     fd	      - File descriptor to listen on.
 *@param[out]    event_info_p  - information regarding the event.
 *
 *@return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 *@return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 *@return SX_SDN_HAL_STATUS_ERROR general error
 *@return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 *@return SX_SDN_HAL_STATUS_NO_RESOURCES device was not opened
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_recv(sx_sdn_hal_fd_t         *fd,
                                         sx_sdn_hal_event_info_t *event_info);

/**
 * This API enables the user to acknowledge the HAL he completed
 * to handle an event.
 *
 *@param[out]    event_info_p  - information regarding the event.
 *
 *@return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 *@return SX_SDN_HAL_STATUS_CMD_UNSUPPORTED if event type is not
 *       supported
 *@return SX_SDN_HAL_STATUS_ERROR general error
 */
sx_sdn_hal_status_t sx_sdn_hal_srvc_event_ack(sx_sdn_hal_event_info_t *event_info);

#endif /* __SX_SDN_HAL_API_EVENTS_H__ */
