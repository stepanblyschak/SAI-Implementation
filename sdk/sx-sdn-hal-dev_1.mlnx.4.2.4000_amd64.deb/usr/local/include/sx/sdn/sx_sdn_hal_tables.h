/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_TABLES_H__
#define __SX_SDN_HAL_TABLES_H__

#define SX_SDN_HAL_MAX_TABLE_ID 0
#define MAX_TABLE_NAME_LENGTH   32

typedef uint32_t sx_sdn_hal_table_id_t;
typedef uint32_t sx_sdn_hal_mcg_id_t;
typedef uint64_t sx_sdn_hal_flow_id_t;
typedef uint64_t sx_sdn_hal_capabilities_flags_t;


/**
 * sx_sdn_hal_activity_method_t enumerated type is used to note
 * activity method available types
 */
typedef enum sx_sdn_hal_activity_method {
    SX_SDN_HAL_ACTIVITY_NOT_SUPPORTED,      /**< Activity check not supported */
    SX_SDN_HAL_ACTIVITY_POLL,               /**< user can poll activity using API */
} sx_sdn_hal_activity_method_t;

/**
 * sx_sdn_hal_table_capabilities struct contains table
 * capabilities parameters
 */
typedef struct sx_sdn_hal_table_capabilities {
    char                            table_name[MAX_TABLE_NAME_LENGTH];      /**< Table name */
    uint32_t                        table_size;                             /**< Table size */
    sx_sdn_hal_activity_method_t    activity_method;                        /**< Activity check method */
    sx_sdn_hal_capabilities_flags_t instruction_capabilities;               /**< Instruction, instruction miss capabilities flags */
    sx_sdn_hal_capabilities_flags_t next_table_capabilities;                /**< Next table, next table miss capabilities flags */
    sx_sdn_hal_capabilities_flags_t apply_action_capabilities;              /**< Apply action capabilities */
    sx_sdn_hal_capabilities_flags_t match_capabilities;                     /**< Match capabilities */
    sx_sdn_hal_capabilities_flags_t wildcard_capabilities;                  /**< Wildcards capabilities */
    sx_sdn_hal_capabilities_flags_t apply_setfield_capabilities;            /**< Apply Set-Field capabilities */
} sx_sdn_hal_table_capabilities_t;

/**
 * sx_sdn_hal_table_module_capabilities_t struct contains table
 * module capabilities parameters
 */
typedef struct sx_sdn_hal_table_module_capabilities {
    uint32_t number_of_tables;                  /**< Number of supported tables */
} sx_sdn_hal_table_module_capabilities_t;


/**
 * sx_sdn_hal_flow_match_t struct holds the relevant fields for
 * flow matching
 */

typedef struct sx_sdn_hal_flow_match {
    sx_sdn_hal_port_t in_port;                  /**< Input switch port */
    uint8_t           in_port_mask;             /**< Mask input port (0 - port is not considered o/w it is)*/
    uint8_t           dl_src[ETH_ALEN];         /**< Ethernet source address*/
    uint8_t           dl_src_mask[ETH_ALEN];    /**< Ethernet source mask */
    uint8_t           dl_dst[ETH_ALEN];         /**< Ethernet destination address */
    uint8_t           dl_dst_mask[ETH_ALEN];    /**< Ethernet destination mask */
    uint8_t           dl_is_tagged;             /**< Is it a vlan tagged frame */
    uint8_t           dl_is_tagged_mask;        /**< Mask is_tagged field (0 - don't care if packet is un/tagged) */
    uint16_t          dl_vlan;                  /**< vlan id */
    uint16_t          dl_vlan_mask;             /**< vlan id mask */
    uint8_t           dl_vlan_pcp;              /**< Vlan priority */
    uint8_t           dl_vlan_pcp_mask;         /**< Vlan priority mask */
    uint16_t          dl_type;                  /**< Ethernet frame type*/
    uint16_t          dl_type_mask;             /**< Ethernet frame type mask*/
    uint8_t           nw_tos;                   /**< IP ToS */
    uint8_t           nw_tos_mask;              /**< IP ToS mask */
    uint8_t           nw_proto;                 /**< IP protocol or lower 8 bits of ARP opcode */
    uint8_t           nw_proto_mask;            /**< IP protocol or lower 8 bits of ARP opcode mask*/
    uint32_t          nw_src;                   /**< IP source address */
    uint32_t          nw_src_mask;              /**< IP source address mask */
    uint32_t          nw_dst;                   /**< IP destination address */
    uint32_t          nw_dst_mask;              /**< IP destination address mask*/
    uint16_t          tp_src;                   /**< TCP/UDP source port */
    uint16_t          tp_src_mask;              /**< TCP/UDP source port mask*/
    uint16_t          tp_dst;                   /**< TCP/UDP destination port*/
    uint16_t          tp_dst_mask;              /**< TCP/UDP destination port mask*/
} sx_sdn_hal_flow_match_t;

/**
 * sx_sdn_hal_flow_output_action_type_t enumerated type is used
 * to note flow output action available types
 */
typedef enum sx_sdn_hal_flow_output_action_type {
    SX_SDN_HAL_FLOW_OUTPUT_NOP,                 /**< No operation */
    SX_SDN_HAL_FLOW_OUTPUT_DROP,                /**< Drop */
    SX_SDN_HAL_FLOW_OUTPUT_PORT,                /**< Redirect to specific port */
    SX_SDN_HAL_FLOW_OUTPUT_TRAP,                /**< Trap to CPU*/
    SX_SDN_HAL_FLOW_OUTPUT_FLOOD,               /**< Flood to all OF ports*/
    SX_SDN_HAL_FLOW_OUTPUT_MCAST,               /**< Output to a predefined multicast group */
    SX_SDN_HAL_FLOW_OUTPUT_ALL                  /**< send to all ports (disregards STP state)*/
} sx_sdn_hal_flow_output_action_type_t;


/**
 * sx_sdn_hal_flow_output_action_t struct holds information on
 * the flow output action
 */
typedef struct sx_sdn_hal_flow_output_action {
    sx_sdn_hal_flow_output_action_type_t type;              /**< Flow output action type */
    sx_sdn_hal_port_t                    output_port;       /**< output port, valid for output_port action type*/
    sx_sdn_hal_mcg_id_t                  mcg_id;            /** Multicast group ID - used when action type is multicast */
} sx_sdn_hal_flow_output_action_t;


/**
 * sx_sdn_hal_flow_vlan_pcp_action_type_t enumerated type is
 * used to note Vlan or priority actions available
 */
typedef enum sx_sdn_hal_flow_vlan_pcp_action_type {
    SX_SDN_HAL_FLOW_VLAN_PCP_NOP,                           /**< No operation on Vlan or priority  */
    SX_SDN_HAL_FLOW_VLAN_PCP_SET_VLAN_ONLY,                 /**< Set Vlan ID  */
    SX_SDN_HAL_FLOW_VLAN_PCP_SET_PCP_ONLY,                  /**< Set priority  */
    SX_SDN_HAL_FLOW_VLAN_PCP_SET_VLAN_PCP,                  /**< Set Vlan and priority */
    SX_SDN_HAL_FLOW_VLAN_PCP_STRIP,                         /**< Strip Vlan */
    SX_SDN_HAL_FLOW_VLAN_PCP_PUSH_VLAN_PCP,                 /**< Push Vlan and priority */
    SX_SDN_HAL_FLOW_VLAN_PCP_PUSH_VLAN_ONLY,                /**< Push Vlan and keep priority */
} sx_sdn_hal_flow_vlan_pcp_action_type_t;


/**
 * sx_sdn_hal_flow_vlan_pcp_action_t struct holds information on
 * the flow vlan/priority actions
 */
typedef struct sx_sdn_hal_flow_vlan_pcp_action {
    sx_sdn_hal_flow_vlan_pcp_action_type_t type;            /**< Vlan action type */
    uint16_t                               vlan;            /**< Vlan - valid when setting Vlan */
    uint8_t                                priority;        /**< Priority - valid when setting priority */
} sx_sdn_hal_flow_vlan_pcp_action_t;


/**
 * sx_sdn_hal_flow_action_t struct holds information on the
 * flows required actions
 */
typedef struct sx_sdn_hal_flow_action {
    sx_sdn_hal_flow_output_action_t   output;      /**< Output to port or queue actions*/
    sx_sdn_hal_flow_vlan_pcp_action_t vlan_pcp;    /**< Set vlan and priority or strip vlan actions */
} sx_sdn_hal_flow_action_t;

typedef struct sx_sdn_hal_flow_attributes {
    sx_sdn_hal_flow_id_t     flow_id;               /**< Unique flow identifier */
    uint32_t                 priority;              /**< Flow priority, higher number gets higher priority */
    sx_sdn_hal_flow_match_t  match;                 /**< Match fields */
    sx_sdn_hal_flow_action_t action;                /**< Action to be taken when match occurs*/
} sx_sdn_hal_flow_attributes_t;


/**
 * sx_sdn_hal_flow_statistics_t struct holds information on per
 * flow statistics
 */
typedef struct sx_sdn_hal_flow_statistics {
    uint64_t received_packets;
    uint64_t received_bytes;
} sx_sdn_hal_flow_statistics_t;


/**
 * sx_sdn_hal_table_statistics_t struct holds information on per
 * table statistics
 */
typedef struct sx_sdn_hal_table_statistics {
    uint32_t max_entries;                           /**< Maximal table entries */
    uint32_t active_count;                          /**< not supported */
    uint32_t lookup_count;                          /**< not supported */
    uint32_t matched_count;                         /**< not supported */
} sx_sdn_hal_table_statistics_t;

/**
 * sx_sdn_hal_flow_activity_t enumerated type is used to note
 * Flow activity state
 */
typedef enum sx_sdn_hal_flow_activity {
    SX_SDN_HAL_FLOW_ACTIVITY_INACTIVE,
    SX_SDN_HAL_FLOW_ACTIVITY_ACTIVE,
    SX_SDN_HAL_FLOW_ACTIVITY_ENTRY_NOT_FOUND,
} sx_sdn_hal_flow_activity_t;

#endif /* __SX_SDN_HAL_TABLES_H__ */
