/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_PORT_H__
#define __SX_SDN_HAL_PORT_H__

#include <net/ethernet.h>

#include <sx/sdn/sx_sdn_hal_general.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SDN HAL port ID.
 */
typedef uint32_t sx_sdn_hal_port_t;

/**
 * SDN HAL port ID ranges.
 */
#define SX_SDN_HAL_PORT_MIN 0x0001
#define SX_SDN_HAL_PORT_MAX 0xFFFF

#define SX_SDN_HAL_PHY_PORT_MIN 0x0001
#define SX_SDN_HAL_PHY_PORT_MAX 0x7FFF

#define SX_SDN_HAL_LAG_PORT_MIN 0x8000
#define SX_SDN_HAL_LAG_PORT_MAX 0xFEFF

#define SX_SDN_HAL_PORT_CHECK_RANGE(PORT) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_PORT_MIN, PORT, SX_SDN_HAL_PORT_MAX)

/**
 * SDN HAL invalid port ID.
 */
#define SX_SDN_HAL_PORT_INVALID 0x0000

/**
 * SDN HAL port name len.
 */
#define SX_SDN_HAL_PORT_NAME_LEN 16

/**
 * SDN HAL port capabilities.
 */
typedef struct sx_sdn_hal_port_capabilities {
    boolean_t autoneg_supported;
} sx_sdn_hal_port_capabilities_t;

/**
 * SDN HAL port capabilities.
 */
typedef enum sx_sdn_hal_port_state {
    SX_SDN_HAL_PORT_STATE_NA,
    SX_SDN_HAL_PORT_STATE_DOWN,
    SX_SDN_HAL_PORT_STATE_UP,

    SX_SDN_HAL_PORT_STATE_MIN = SX_SDN_HAL_PORT_STATE_NA,
    SX_SDN_HAL_PORT_STATE_MAX = SX_SDN_HAL_PORT_STATE_UP,
} sx_sdn_hal_port_state_t;

static __attribute__((__used__)) const char *sx_sdn_hal_port_state_str_arr[] = {
    "N/A",
    "DOWN",
    "UP",
};

#define SX_SDN_HAL_PORT_STATE_CHECK_RANGE(STATE) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_PORT_STATE_MIN, (int)STATE, SX_SDN_HAL_PORT_STATE_MAX)

#define SX_SDN_HAL_PORT_STATE_STR(STATE)       \
    SX_SDN_HAL_PORT_STATE_CHECK_RANGE(STATE) ? \
    sx_sdn_hal_port_state_str_arr[STATE] : "Unknown port state"

/**
 * SDN HAL MAC address.
 */
typedef struct ether_addr sx_sdn_hal_mac_addr_t;

/**
 * SDN HAL port speed operation.
 */
typedef enum sx_sdn_hal_port_speed_oper {
    SX_SDN_HAL_PORT_SPEED_NA,
    SX_SDN_HAL_PORT_SPEED_1GB,
    SX_SDN_HAL_PORT_SPEED_10GB,
    SX_SDN_HAL_PORT_SPEED_40GB,
    SX_SDN_HAL_PORT_SPEED_56GB,
} sx_sdn_hal_port_speed_oper_t;

/**
 * SDN HAL port speed capability.
 * This struct stores port's enabled spped(s). Each speed mode
 * can be set to Enabled/Disabled. It is possible to enable
 * several speed modes.
 */
typedef struct sx_sdn_hal_port_speed_capability {
    boolean_t mode_1GB;
    boolean_t mode_10GB;
    boolean_t mode_40GB;
    boolean_t mode_56GB;
} sx_sdn_hal_port_speed_capability_t;

#define SX_SDN_HAL_PORT_SPEED_CAPABILITY_CHECK_RANGE(SPEED_CAPABILITY) \
    (SX_SDN_HAL_CHECK_BOOLEAN((SPEED_CAPABILITY).mode_1GB) &&          \
     SX_SDN_HAL_CHECK_BOOLEAN((SPEED_CAPABILITY).mode_10GB) &&         \
     SX_SDN_HAL_CHECK_BOOLEAN((SPEED_CAPABILITY).mode_40GB) &&         \
     SX_SDN_HAL_CHECK_BOOLEAN((SPEED_CAPABILITY).mode_56GB))

/**
 * SDN HAL port flood mode.
 */
typedef enum sx_sdn_hal_port_flood_mode {
    SX_SDN_HAL_PORT_FLOOD_MODE_DISABLE,
    SX_SDN_HAL_PORT_FLOOD_MODE_ENABLE,
} sx_sdn_hal_port_flood_mode_t;

/**
 * SDN HAL port mtu.
 */
typedef uint16_t sx_sdn_hal_port_mtu_t;

/**
 * SDN HAL port MTU ranges.
 */
#define SX_SDN_HAL_PORT_MTU_MIN 68
#define SX_SDN_HAL_PORT_MTU_MAX 10000

#define SX_SDN_HAL_PORT_MTU_CHECK_RANGE(MTU) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_PORT_MTU_MIN, MTU, SX_SDN_HAL_PORT_MTU_MAX)

/**
 * SDN HAL port counter.
 */
typedef uint64_t sx_sdn_hal_port_cntr_t;

/**
 * SDN HAL port counters.
 */
typedef struct sx_sdn_hal_port_cntr_of {
    sx_sdn_hal_port_cntr_t port_rx_octets;
    sx_sdn_hal_port_cntr_t port_rx_pkts;
    sx_sdn_hal_port_cntr_t port_rx_dropped;
    sx_sdn_hal_port_cntr_t port_rx_errors;
    sx_sdn_hal_port_cntr_t port_rx_alignment_errors;
    sx_sdn_hal_port_cntr_t port_rx_oversize_errors;
    sx_sdn_hal_port_cntr_t port_rx_crc_errors;
    sx_sdn_hal_port_cntr_t port_tx_octets;
    sx_sdn_hal_port_cntr_t port_tx_pkts;
    sx_sdn_hal_port_cntr_t port_tx_dropped;
    sx_sdn_hal_port_cntr_t port_tx_errors;
    sx_sdn_hal_port_cntr_t port_collisions;
} sx_sdn_hal_port_cntr_of_t;

#endif /* __SX_SDN_HAL_PORT_H__ */
