/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_GENERAL_H__
#define __SX_SDN_HAL_GENERAL_H__


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  MACRO definitions
 ***********************************************/

#ifndef UNUSED_PARAM
#define UNUSED_PARAM(PARAM) ((void)(PARAM))
#endif

#define SX_SDN_HAL_CHECK_MAX(VAL, MAX) \
    ((VAL) <= (MAX))

#define SX_SDN_HAL_CHECK_RANGE(MIN, VAL, MAX) \
    ((MIN <= VAL) && (VAL <= MAX))

#define SX_SDN_HAL_CHECK_BOOLEAN(val) \
    SX_SDN_HAL_CHECK_RANGE(0, val, 1)

#define SX_SDN_HAL_CHECK_FAIL(STATUS) (SX_SDN_HAL_STATUS_SUCCESS != (STATUS))

#endif /* __SX_SDN_HAL_GENERAL_H__ */
