/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_STP_H__
#define __SX_SDN_HAL_STP_H__


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SDN HAL STP port state.
 */
typedef enum sx_sdn_hal_stp_port_state {
    SX_SDN_HAL_STP_PORT_STATE_NA,
    SX_SDN_HAL_STP_PORT_STATE_DISCARDING,
    SX_SDN_HAL_STP_PORT_STATE_LEARNING,
    SX_SDN_HAL_STP_PORT_STATE_FORWARDING,

    SX_SDN_HAL_STP_PORT_STATE_MIN = SX_SDN_HAL_STP_PORT_STATE_NA,
    SX_SDN_HAL_STP_PORT_STATE_MAX = SX_SDN_HAL_STP_PORT_STATE_FORWARDING,
} sx_sdn_hal_stp_port_state_t;

static __attribute__((__used__)) const char *sx_sdn_hal_stp_port_state_str_arr[] = {
    "N/A",
    "DISCARDING",
    "LEARNING",
    "FORWARDING",
};

#define SX_SDN_HAL_STP_PORT_STATE_CHECK_RANGE(STATE) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_STP_PORT_STATE_MIN, (int)STATE, SX_SDN_HAL_STP_PORT_STATE_MAX)

#define SX_SDN_HAL_STP_PORT_STATE_STR(STATE)       \
    SX_SDN_HAL_STP_PORT_STATE_CHECK_RANGE(STATE) ? \
    sx_sdn_hal_stp_port_state_str_arr[STATE] : "Unknown stp port state"


#endif /* __SX_SDN_HAL_STP_H__ */
