/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __RESOURCE_MANAGER_H__
#define __RESOURCE_MANAGER_H__

#include <complib/cl_types.h>
#include <sx/sdk/sx_dev.h>
#include <sx/sdk/sx_status.h>
/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define UNTAGGED_PG (8)
/*ceil[spectrum,switch_a2,switch_a1,pelican]*/
#define RM_API_ROUTER_RIFS_MAX                   (400)
#define RM_API_ROUTER_VIFS_MAX                   (400)
#define RM_API_ROUTER_NEXT_HOP_MAX               (64)
#define RM_API_COS_TRAFFIC_CLASS_NUM             (8)
#define RM_API_COS_BUFFERS_NUM                   (8)
#define RM_API_COS_PORT_PRIO_MAX                 (14)
#define RM_API_ACL_PORT_RANGES_MAX               (16) /* Used for static array of ranges both legacy and new APIs */
#define RM_API_ACL_PORT_LIST_MAX                 (64)
#define RM_API_ACL_RULES_BLOCK_MAX               (20) /* Legacy definition */
#define RM_API_ACL_FLEX_RULES_BLOCK_MAX          (20)
#define RM_API_ACL_MAX_FIELDS_IN_KEY             (40)
#define RM_API_ACL_MAX_KEYS_IN_RULE              (30)
#define RM_API_ACL_MAX_ACTIONS_IN_RULE           (20)
#define RM_API_ACL_MAX_BYTES_IN_CUSTOM_BYTES_SET (4)
#define RM_API_HOST_IFC_USER_DEFINE_KEY_MAX      (2)
#define RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX   (4)
#define UNLIMITED_SDK_TABLE_SIZE                 0xFFFFFFFF
#define COS_PCP_MAX_NUM                          7
#define COS_DEI_MAX_NUM                          1
#define COS_EXP_MAX_NUM                          7
#define COS_ECN_MAX_NUM                          3
#define COS_DSCP_MAX_NUM                         63
#define COS_IEEE_PRIO_MAX_NUM                    7
#define RM_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX  4096
#define RM_NUM_OF_SWIDS                          (rm_resource_global.swid_id_max + 1)
#define RM_COMMON_CUSTOM_BYTES_ENUM_START        2000 /** Common definition of Custom bytes for ACL and ECMP Hash */

/************************************************
 *  Macros
 ***********************************************/
#define CL_FREE_N_NULL(x) { cl_free(x); x = NULL; } /* while (0) */

#define RM_SWID_CHECK_RANGE(swid_id) ((SX_SWID_ID_STACKING == swid_id) || (swid_id <= rm_resource_global.swid_id_max))
#define RM_SWID_CHECK_MAX(swid_id)   (swid_id <= rm_resource_global.swid_id_max)

#define RM_PORT_CNT_CHECK_MAX(port_cnt) (port_cnt <= rm_resource_global.port_lcl_num_max)
#define RM_PORT_STORM_CONTROL_CHECK_MAX(storm_control_id) \
    (storm_control_id <=                                  \
     rm_resource_global.port_storm_control_id_max)
#define RM_PORT_STORM_CONTROL_CHECK_RANGE(storm_control_id) \
    (storm_control_id > 0 && storm_control_id <=            \
     rm_resource_global.port_storm_control_id_max)

#define RM_ROUTER_VRID_CHECK_MAX(vrid)     (vrid <= rm_resource_global.router_vrid_max)
#define RM_ROUTER_VRID_NUM_CHECK_MAX(vrid) (vrid <= rm_resource_global.router_vrid_max + 1)
#define RM_ROUTER_RIF_CHECK_MAX(rif)       (rif <= rm_resource_global.router_rifs_max)
#define RM_ROUTER_RIF_CHECK_DONT_CARE(rif) (rif == rm_resource_global.router_rifs_dontcare)
#define RM_ROUTER_UC_IPV4_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max)
#define RM_ROUTER_UC_IPV6_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max)
#define RM_ROUTER_MC_IPV4_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max)
#define RM_ROUTER_MC_IPV6_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max)
#define RM_ROUTER_IPV4_NEIGHS_CHECK_MAX(neighs) \
    ((neighs) <= rm_resource_global_default.router_neigh_max)
#define RM_ROUTER_IPV6_NEIGHS_CHECK_MAX(neighs) \
    ((neighs) <= rm_resource_global_default.router_neigh_max)

#define RM_ACL_RULES_BLOCK_MAX_CHECK_MAX(acl_rules_block) (acl_rules_block <= RM_API_ACL_RULES_BLOCK_MAX)
#define RM_ACL_PORT_CHECK_MAX(range_id)                   (range_id <= (rm_resource_global.acl_port_ranges_max - 1))

#define RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id) \
    (span_session_id <= rm_resource_global.span_session_id_max_internal)
#define RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id) \
    (span_session_id <= rm_resource_global.span_session_id_max_external)

#define RM_VLAN_ID_CHECK_RANGE(vid) ((vid <= rm_resource_global.vlan_id_max) && vid > 0)
#define RM_VLAN_ID_CHECK_MAX(vid)   (vid <= rm_resource_global.vlan_id_max)

#define RM_LAG_ID_CHECK_MAX(lid)   (lid <= rm_resource_global.lag_num_max)
#define RM_LAG_ID_CHECK_RANGE(lid) ((lid <= rm_resource_global.lag_num_max) && lid > 0)

#define SX_RESOURCE_CHECK_RANGE(RESOURCE)   \
    SX_CHECK_RANGE(RM_SDK_TABLE_TYPE_MIN_E, \
                   (int)RESOURCE,           \
                   RM_SDK_TABLE_TYPE_MAX_E)
#define SX_RESOURCE_MSG(RESOURCE)                                       \
    SX_RESOURCE_CHECK_RANGE(RESOURCE) ? sx_resource2str_arr[RESOURCE] : \
    "Unknown resource"

#define RM_ROUTER_ECMP_HASH_CHECK_RANGE(ecmp_hash) \
    (ecmp_hash <= rm_resource_global.router_ecmp_hash_max)

#define RM_ROUTER_COUNTER_ID_CHECK_MAX(cntr_id) \
    (cntr_id <= rm_resource_global.router_counters_id_max)

#define RM_SPAN_SESSION_ID_CHECK_RANGE(span_session_id) (span_session_id <= rm_resource_global.span_session_id_max)

#define RM_PORT_INGRESS_SHARED_BUFFER_POOL_ID_CHECK_RANGE(pool_id) \
    (pool_id < rm_resource_global.                                 \
     shared_buff_num_ingress_pools)
#define RM_PORT_INGRESS_SHARED_BUFFER_HARDWARE_POOL_ID_CHECK_RANGE(pool_id) \
    (pool_id < rm_resource_global.                                          \
     shared_buff_num_ingress_pools)
#define RM_PORT_INGRESS_SHARED_BUFFER_PG_ID_CHECK_RANGE(pg) \
    ((pg <= rm_resource_global.shared_buff_num_port_ingress_buff) && (pg != UNTAGGED_PG))
#define RM_PORT_EGRESS_SHARED_BUFFER_POOL_ID_CHECK_RANGE(pool_id) \
    ((pool_id >= rm_resource_global.                              \
      shared_buff_num_ingress_pools) &&                           \
     (pool_id < rm_resource_global.                               \
      shared_buff_total_num_pools))
#define RM_PORT_EGRESS_SHARED_BUFFER_HARDWARE_POOL_ID_CHECK_RANGE(pool_id) \
    (pool_id < rm_resource_global.                                         \
     shared_buff_num_egress_pools)


#define RM_PORT_EGRESS_SHARED_BUFFER_TC_ID_CHECK_RANGE(tc) \
    (tc < rm_resource_global.                              \
     shared_buff_num_port_egress_buff)
#define RM_MULTICAST_SHARED_BUFFER_ID_CHECK_RANGE(mc) \
    (mc < rm_resource_global.                         \
     shared_buff_mc_max_num_prio)

#define RM_IB_ROUTER_UC_LID_CHECK_RANGE(uc_lid)             \
    ((uc_lid <= rm_resource_global.ib_router_uc_lid_max) && \
     (uc_lid >= rm_resource_global.ib_router_uc_lid_min))
#define RM_IB_ROUTER_QPN_CHECK_MAX(qpn) (qpn <= rm_resource_global.ib_router_qpn_max)

#define RM_TRAP_GROUP_PRIORITY_CHECK_RANGE(__priority)                 \
    (((__priority) <= (rm_resource_global.trap_group_priority_max)) && \
     ((__priority) >= (rm_resource_global.trap_group_priority_min)))

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum {
    RM_SDK_TABLE_TYPE_UC_MAC_E = 0,
    RM_SDK_TABLE_TYPE_MC_MAC_E = 1,
    RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E = 2,
    RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E = 3,
    RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E = 4,
    RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E = 5,
    RM_SDK_TABLE_TYPE_ARP_IPV4_E = 6,
    RM_SDK_TABLE_TYPE_ARP_IPV6_E = 7,
    RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E = 8,
    RM_SDK_TABLE_TYPE_ADJACENCY_E = 9,
    RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E = 10,
    RM_SDK_TABLE_TYPE_LAG_VECTORS_E = 11,
    RM_SDK_TABLE_TYPE_FLOOD_VECTORS_E = 12,
    RM_SDK_TABLE_TYPE_FCF_FORWORDING_E = 13,
    RM_SDK_TABLE_TYPE_ACL_RULES_E = 14,
    RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E = 15,
    RM_SDK_TABLE_TYPE_ACL_GROUPS_E = 16,
    RM_SDK_TABLE_TYPE_ACL_PBS_E = 17,
    /* Entry 18 Removed - IB MC Adjacency not in use anymore */
    RM_SDK_TABLE_TYPE_ERIF_LIST_E = 19,
    RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E = 20,
    RM_SDK_TABLE_TYPE_DECAP_RULES_E = 21,
    RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E = 22,
    RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E = 23,
    RM_SDK_TABLE_TYPE_RMID_MANAGER_E = 24,
    RM_SDK_TABLE_TYPE_NVE_MC_LIST_E = 25,
    RM_SDK_TABLE_TYPE_SMID_MANAGER_E = 26,
    RM_SDK_TABLE_TYPE_IGMP_V3_E = 27,
    RM_SDK_TABLE_TYPE_ILM_E = 28,
    RM_SDK_TABLE_TYPE_MIN_E = RM_SDK_TABLE_TYPE_UC_MAC_E,
    RM_SDK_TABLE_TYPE_MAX_E = RM_SDK_TABLE_TYPE_ILM_E,
} rm_sdk_table_type_e;
#define RM_SDK_TABLE_TYPE_NUMBER (RM_SDK_TABLE_TYPE_MAX_E - RM_SDK_TABLE_TYPE_MIN_E + 1)


typedef struct rm_hw_table_attrb {
    boolean_t rm_hw_table_supported;
    uint32_t  rm_hw_table_size;
} rm_hw_table_attrb_t;

typedef enum {
    RM_HW_TABLE_TYPE_TCAM_E = 0,
    RM_HW_TABLE_TYPE_LINEAR_E = 1,
    RM_HW_TABLE_TYPE_KVD_HASH_E = 2,
    RM_HW_TABLE_TYPE_KVD_LINEAR_E = 3,
    RM_HW_TABLE_TYPE_ADJACENCY_E = 4,
    RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E = 5,
    RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E = 6,
    RM_HW_TABLE_TYPE_PGT_E = 7,
    RM_HW_TABLE_TYPE_MIN_E = RM_HW_TABLE_TYPE_TCAM_E,
    RM_HW_TABLE_TYPE_MAX_E = RM_HW_TABLE_TYPE_PGT_E,
} rm_hw_table_type_e;
#define RM_HW_TABLE_TYPE_INVALID RM_HW_TABLE_TYPE_MAX_E + 1
#define RM_HW_TABLE_TYPE_NUMBER  (RM_HW_TABLE_TYPE_MAX_E - RM_HW_TABLE_TYPE_MIN_E + 1)

typedef struct sw_table_resource {
    uint32_t           table_size_min;
    uint32_t           table_size_max;
    uint32_t           entry_cost;
    rm_hw_table_type_e hw_table_type;
    boolean_t          is_initialized;
} rm_sw_table_resource_t;

typedef struct rm_resources {
    /*13*/
    uint32_t acl_ingress_groups_max;
    uint32_t acl_engress_groups_max;
    uint32_t acl_groups_size_max;
    uint32_t acl_groups_num_max;
    uint32_t acl_rules_block_max;
    uint32_t acl_pbs_entries_max;
    uint32_t acl_port_ranges_max;       /* cap max_acl_l4_port_ranges */
    uint32_t acl_regions_max;           /* cap_max_acl_regions */
    uint32_t acl_ingress_tables_max;    /* backward compat */
    uint32_t acl_egress_tables_max;     /* backward compat */
    uint32_t acl_tables_max;            /* cap_max_acl_regions */
    uint32_t acl_vlan_groups_max;       /* cap_max_acl_vlan_groups  */
    uint32_t acl_trap_groups_max;
    uint32_t acl_max_flex_keys;         /* cap_flexible_keys */
    uint32_t acl_max_actions_per_rule;  /* cap_max_action_per_rule */
    uint32_t acl_max_actions_per_set;   /* cap_actions_per_set */
    uint32_t acl_parsing_depth;
    uint32_t acl_custom_bytes_set_max;      /* Max number of sets */
    uint32_t acl_custom_bytes_set_size_max; /* Set size */
    uint32_t acl_custom_bytes_extraction_point_offset_max;

    /*20*/
    uint32_t router_rifs_max;
    uint32_t router_rifs_dontcare;
    uint32_t router_sub_port_fid_start_index;
    uint32_t router_ipv4_uc_max;
    uint32_t router_ipv4_mc_max;
    uint32_t router_ipv6_uc_max;
    uint32_t router_ipv6_mc_max;
    uint32_t router_ecmp_max;
    uint32_t router_ecmp_hash_max;
    uint32_t router_adj_max;
    uint32_t router_neigh_max;
    uint32_t router_vrid_max;
    uint32_t router_counters_id_max;
    uint32_t router_next_hop_max;
    uint32_t router_ecmp_container_tot_weight_max;
    uint32_t router_shspm_tree_max;
    uint32_t router_shspm_unicast_entry_max;
    uint32_t router_mc_rpf_group_max;

    /*5*/
    uint32_t fcf_port_density_max;
    uint32_t fcf_zones_pairs_max;
    uint32_t fcf_zones_groups_max;
    uint32_t fcf_gateway_max;
    uint32_t fcf_rules_max;

    /*8*/
    uint32_t port_lcl_num_max;
    uint32_t port_ext_num_max;
    uint32_t port_log_num_max;
    uint32_t port_mtu_max;
    uint32_t port_mtu_min;
    uint32_t port_storm_control_id_max;
    uint32_t port_vepa_channels_num_max;
    uint32_t port_system_ports_max;
    uint32_t port_system_port_modules_max;

    /*6*/
    uint32_t  lag_num_max;
    uint32_t  lag_port_members_max;
    uint32_t  span_session_id_max_internal; /* supported by FW      */
    uint32_t  span_session_id_max_external; /* available to user    */
    uint32_t  fdb_mid_max;
    uint32_t  fdb_mid_start_index;
    uint32_t  fdb_pgt_max;
    uint32_t  fdb_uc_address_max;
    uint32_t  fdb_mc_address_max;
    uint32_t  flooding_table_max;
    uint32_t  flooding_table_per_vid_max;
    uint32_t  cos_port_ets_traffic_class_max;
    uint32_t  cos_port_ets_sub_group_max;
    uint32_t  cos_port_ets_group_max;
    uint32_t  cos_port_prio_max;
    uint32_t  cos_port_color_max;
    uint32_t  cos_port_ets_elements_num;
    double    cos_buffer_64k_size_max;
    double    cos_buffer_128k_size_max;
    uint32_t  cos_redecn_default_aqs_weight;
    boolean_t cos_redecn_red_drop_enabled;
    boolean_t cos_redecn_scd;
    uint32_t  cos_redecn_profiles_max;
    uint32_t  cos_redecn_cell_multiplier;
    boolean_t cos_redecn_default_tc_red_enabled;
    boolean_t cos_redecn_default_tc_ecn_enabled;
    uint8_t   swid_id_max;
    uint32_t  policer_pool_size;
    uint32_t  policer_host_ifc_pool_size;
    uint32_t  policer_storm_control_pool_size;
    uint32_t  policer_bs_min_value_packets;
    uint32_t  policer_bs_min_value_bytes;
    uint32_t  policer_bs_max_value;
    uint32_t  kvd_size;
    uint32_t  kvd_hash_single_min_size;
    uint32_t  kvd_hash_double_min_size;
    double    kvd_guaranteed_capacity;
    uint32_t  pgt_size;
    uint32_t  rmpe_size;

    /* Bridge */
    uint32_t bridge_num_max;

    /* Shared buffer */
    uint32_t               total_buffer_space; /* cap_total_buffer_size */
    uint32_t               max_total_headroom_size;
    uint8_t                headroom_num_port_buff;
    uint8_t                shared_buff_num_ingress_pools;
    uint8_t                shared_buff_num_egress_pools;
    uint8_t                shared_buff_total_num_pools;
    uint8_t                shared_buff_num_port_egress_buff;
    uint8_t                shared_buff_num_port_ingress_buff;
    uint32_t               shared_buff_max_pool_size;
    uint32_t               max_num_of_port;
    uint32_t               max_num_of_tclass;
    uint32_t               max_num_of_statistics_ret_values;
    uint32_t               shared_buff_buffer_unit_size; /*cap_cell_size*/
    uint32_t               shared_buff_mc_max_num_prio;
    rm_sw_table_resource_t rm_sdk_tables_db[RM_SDK_TABLE_TYPE_NUMBER];
    rm_hw_table_attrb_t    rm_hw_tables_attrb[RM_HW_TABLE_TYPE_NUMBER];

    /* 16 Counters */
    uint8_t  cntr_bank_pairs;
    uint16_t cntr_lines_per_bank;
    uint8_t  cntr_lines_flow_pkt;
    uint8_t  cntr_type_flow_pkt;
    uint8_t  cntr_lines_flow_byte;
    uint8_t  cntr_type_flow_byte;
    uint8_t  cntr_lines_flow_both;
    uint8_t  cntr_type_flow_both;
    uint8_t  cntr_lines_rif_basic;
    uint8_t  cntr_type_rif_basic;
    uint8_t  cntr_lines_rif_mixed_1;
    uint8_t  cntr_type_rif_mixed_1;
    uint8_t  cntr_lines_rif_mixed_2;
    uint8_t  cntr_type_rif_mixed_2;
    uint8_t  cntr_lines_rif_enhanced;
    uint8_t  cntr_type_rif_enhanced;

    /*10*/
    uint32_t ib_router_pkeys_max;
    uint32_t ib_router_lids_max;
    uint32_t ib_router_mc_lids_num_max;
    uint32_t ib_router_uc_lid_num_max;

    /*1*/
    uint32_t ib_ports_max;

    /* Host interface */
    uint32_t hw_trap_groups_num_max;
    uint32_t trap_group_priority_min;
    uint32_t trap_group_priority_max;
    uint32_t rdq_num_max;
    uint32_t cpu_tclass_num_max;

    /* Tunnel */
    uint32_t tunnel_ipinip_num_max;
    uint32_t tunnel_nve_num_max;

    /* IGMP V3 */
    uint32_t igmpv3_entries_max;

    /* Tele */
    uint32_t tele_histogram_num_max;
    uint32_t tele_histogram_queue_depth_bins;
    uint32_t tele_histogram_sample_time_resolution_max;
    uint32_t tele_histogram_bin_size_resolution_min;
    uint32_t tele_histogram_bin_size_resolution_max;
    uint32_t tele_histogram_data_bin_bits_max;
    uint32_t tele_histogram_min_boundary_min;
} rm_resources_t;


/************************************************
 *  Global variables
 ***********************************************/


extern rm_resources_t rm_resource_global;
extern rm_resources_t rm_resource_global_default;

#define SX_SDK_RESOURCE_CHECK_RANGE(RESOURCE) \
    SX_CHECK_RANGE(RM_SDK_TABLE_TYPE_MIN_E,   \
                   (int)RESOURCE,             \
                   RM_SDK_TABLE_TYPE_MAX_E)

static __attribute__((__used__)) const char *sx_resource2str_arr[] = {
    /*RM_SDK_TABLE_TYPE_UC_MAC = 0*/
    "UC MAC Table ",

    /*RM_SDK_TABLE_TYPE_MC_MAC = 1*/
    "MC MAC Table ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV4_UC = 2*/
    "FIB IPV4 UC Table ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV6_UC = 3*/
    "FIB IPV6 UC Table ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV4_MC = 4*/
    "FIB IPV4 MC Table ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV6_MC = 5*/
    "FIB IPV6 MC Table ",

    /*RM_SDK_TABLE_TYPE_ARP_IPV4 = 6*/
    "ARP IPV4 Table ",

    /*RM_SDK_TABLE_TYPE_ARP_IPV6 = 7*/
    "ARP IPV6 Table ",

    /*RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS = 8*/
    "L3 MC REPLICATIONS Table ",

    /*RM_SDK_TABLE_TYPE_ADJACENCY_E = 9*/
    "Unicast Adjacency Table ",

    /*RM_SDK_TABLE_TYPE_L2_MC_VECTORS = 10*/
    "L2 MC VECTORS Table ",

    /*RM_SDK_TABLE_TYPE_LAG_VECTORS = 11*/
    "LAG VECTORS Table ",

    /*RM_SDK_TABLE_TYPE_FlOOD_VECTORS = 12*/
    "FlOOD VECTORS Table",

    /*RM_SDK_TABLE_TYPE_FCF_FORWORDING = 13*/
    "FCF FORWORDING Table ",

    /*RM_SDK_TABLE_TYPE_ACL_RULES = 14*/
    "ACL RULES Table ",

    /*RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS = 15 */
    "ACL Extended Actions Table ",

    /*RM_SDK_TABLE_TYPE_ACL_GROUPS = 16*/
    "ACL GROUPS Table ",

    /*RM_SDK_TABLE_TYPE_ACL_PBS_E = 17 */
    "ACL PBS Table",

    /*RM_SDK_TABLE_TYPE_ADJACENCY_MC_E = 18 */
    "Multicast Adjacency Table - Not in Use ",

    /*RM_SDK_TABLE_TYPE_ERIF_LIST_E = 19 */
    "eRIF List ",

    /* RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E = 20 */
    "Tunnel RTDP",

    /* RM_SDK_TABLE_TYPE_DECAP_RULES_E = 21 */
    "Decap rules",

    /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E = 22 */
    "FIB IPV4 MC System Table ",

    /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E = 23 */
    "FIB IPV6 MC System Table ",

    /* RM_SDK_TABLE_TYPE_RMID_MANAGER_E = 24 */
    "RMID Manager Table ",

    /*RM_SDK_TABLE_TYPE_NVE_MC_LIST_E = 25 */
    "NVE MC List",

    /* RM_SDK_TABLE_TYPE_SMID_MANAGER_E = 26 */
    "SMID Manager",

    /* RM_SDK_TABLE_TYPE_IGMP_V3_E = 27 */
    "IGMP V3 table",

    /* RM_SDK_TABLE_TYPE_ILM_E = 28 */
    "ILM Table"
};

#define SX_SDK_RESOURCE_MSG(RESOURCE)                                                            \
    (RESOURCE < (sizeof(sx_resource2str_arr) / sizeof(char*))) ? sx_resource2str_arr[RESOURCE] : \
    "Unknown resource"


#define SX_HW_RESOURCE_CHECK_RANGE(RESOURCE) \
    SX_CHECK_RANGE(RM_HW_TABLE_TYPE_MIN_E,   \
                   (int)RESOURCE,            \
                   RM_HW_TABLE_TYPE_MAX_E)
#define SX_HW_RESOURCE_MSG(RESOURCE)                                          \
    SX_HW_RESOURCE_CHECK_RANGE(RESOURCE) ? sx_hw_resource2str_arr[RESOURCE] : \
    "Unknown resource"

static __attribute__((__used__)) const char *sx_hw_resource2str_arr[] = {
    /*RM_DB_TYPE_TCAM = 0*/
    "TCAM Table ",

    /*RM_DB_TYPE_LINEAR = 1*/
    "Linear Table ",

    /*RM_DB_TYPE_KVD_HASH = 2*/
    "KVD hash Table ",

    /*RM_DB_TYPE_KVD_LINEAR = 3*/
    "KVD linear Table ",

    /*RM_HW_TABLE_TYPE_ADJACENCY_E = 4*/
    "Adjacency Table ",

    /*RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E = 5*/
    "Multicast Replication Matrix ",

    /*RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E = 6*/
    "ACL Group Table ",

    /* RM_HW_TABLE_TYPE_PGT_E = 7 */
    "PGT "
};

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t rm_chip_limits_get(sx_chip_types_t chip_type, rm_resources_t* resource_limits);
#endif /* __RESOURCE_MANAGER_H__ */
