/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_INIT_H__
#define __SX_INIT_H__

typedef enum sx_tcam_opt_mode {
    SX_TCAM_OPT_MODE_DYNAMIC = 0,
    SX_TCAM_OPT_MODE_STATIC,
    SX_TCAM_OPT_MODE_DISABLED,
    SX_TCAM_OPT_MODE_MIN = SX_TCAM_OPT_MODE_DYNAMIC,
    SX_TCAM_OPT_MODE_MAX = SX_TCAM_OPT_MODE_DISABLED,
} sx_tcam_opt_mode_t;

#define SX_TCAM_OPT_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_TCAM_OPT_MODE_MIN,   \
                   (int)mode,              \
                   SX_TCAM_OPT_MODE_MAX)

/**
 * sx_init_tcam_opt_mode_str contains tags for TCAM optimisation mode
 */
extern const char* sx_init_tcam_opt_mode_str[];

#define SX_TCAM_OPT_MODE_STR(mode) \
    (SX_TCAM_OPT_MODE_CHECK_RANGE(mode) ? sx_init_tcam_opt_mode_str[mode] : "UNKNOWN")

typedef enum sx_tcam_opt_mode_param {
    SX_TCAM_OPT_MODE_PARAM_NONE = 0,
    SX_TCAM_OPT_MODE_PARAM_FWS_64B,
    SX_TCAM_OPT_MODE_PARAM_FWS_128B,
    SX_TCAM_OPT_MODE_PARAM_FWS_256B,
    SX_TCAM_OPT_MODE_PARAM_FWS_512B,
    SX_TCAM_OPT_MODE_PARAM_FWS_1024B,
    SX_TCAM_OPT_MODE_PARAM_MIN = SX_TCAM_OPT_MODE_PARAM_NONE,
    SX_TCAM_OPT_MODE_PARAM_MAX = SX_TCAM_OPT_MODE_PARAM_FWS_1024B,
} sx_tcam_opt_mode_param_t;

#define SX_TCAM_OPT_MODE_PARAM_CHECK_RANGE(param) \
    SX_CHECK_RANGE(SX_TCAM_OPT_MODE_PARAM_MIN,    \
                   (int)param,                    \
                   SX_TCAM_OPT_MODE_PARAM_MAX)

/**
 * sx_init_tcam_opt_mode_str contains tags for TCAM optimisation mode parameter
 */
extern const char* sx_init_tcam_opt_mode_param_str[];

#define SX_TCAM_OPT_MODE_PARAM_STR(param)        \
    (SX_TCAM_OPT_MODE_PARAM_CHECK_RANGE(param) ? \
     sx_init_tcam_opt_mode_param_str[param] : "UNKNOWN")

/**
 * sx_tcam_opt_params_t struct is used for holding TCAM optimisation mode and
 * parameters
 */
typedef struct sx_tcam_opt_params {
    sx_tcam_opt_mode_t       tcam_opt_mode;
    sx_tcam_opt_mode_param_t tcam_opt_mode_param;
} sx_tcam_opt_params_t;

#endif /* __SX_INIT_H__ */
