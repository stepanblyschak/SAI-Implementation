/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_LAG_H__
#define __SX_LAG_H__

#include <complib/cl_passivelock.h>
#include <sx/sxd/sxd_lag.h>
#include <sx/sdk/sx_port.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Link aggregation group ID.
 */
typedef uint16_t sx_lag_id_t;

/**
 * Max number of LAGs
 */
#define SX_LAG_ID_MIN   (SXD_LAG_ID_MIN)
#define SX_LAG_ID_MAX   (SXD_LAG_ID_MAX)
#define SX_LAG_ID_COUNT (SX_LAG_ID_MAX - SX_LAG_ID_MIN + 1)
#define SX_LAG_ID_CHECK_RANGE(LAG_ID) SX_CHECK_MAX(LAG_ID, SX_LAG_ID_MAX)

/**
 * Max number of LAGs
 */
#define SX_LAG_MAX_NUM_LAG_PORTS (SX_LAG_ID_MAX - SX_LAG_ID_MIN + 1)

/**
 * Max number of ports per LAG
 */
#define SX_LAG_MAX_PORTS_PER_LAG SXD_LAG_MAX_PORTS
#define SX_LAG_DEFAULT_LAG_HASH  0x01FE
#define SX_LAG_DEFAULT_HASH_TYPE 0
#define SX_LAG_DEFAULT_HASH_SEED 0

#define MAX_LAG_HASH_VALUE 0xFFFFF
#define MIN_LAG_HASH_VALUE 0

#define LAG_SHM_PATH           "/lag"
#define INVALID_LAG_LOG_PORT   0
#define INVALID_LAG_PORT_INDEX 0xFF


typedef enum sx_distributor_mode {
    DISTRIBUTOR_ENABLE,
    DISTRIBUTOR_DISABLE
} sx_distributor_mode_t;

typedef enum sx_collector_mode {
    COLLECTOR_ENABLE,
    COLLECTOR_DISABLE
} sx_collector_mode_t;


/**
 * sx_lag_hash_bit_number_t enum  is used for indicating bit
 * numbers of the hash flow parameters setting in API
 * sx_api_lag_hash_flow_params_set
 */
typedef enum {
    SX_LAG_HASH_INGRESS_PORT = 0,           /**< Igress port accounted in flow hash */
    SX_LAG_HASH_SMAC_IP = 1,                /**< Source MAC accounted in flow hash for IPv4 and IPv6 frames */
    SX_LAG_HASH_SMAC_NON_IP = 2,            /**< Source MAC accounted in flow hash for non IP frames */
    SX_LAG_HASH_DMAC_IP = 3,                /**< Destination MAC accounted in flow hash for IPv4 and IPv6 frames */
    SX_LAG_HASH_DMAC_NON_IP = 4,            /**< Destination MAC accounted in flow hash for non IP frames */
    SX_LAG_HASH_ETHER_IP = 5,               /**< Ethertype accounted in flow hash for IPv4 and IPv6 frames */
    SX_LAG_HASH_ETHER_NON_IP = 6,           /**< Ethertype accounted in flow hash for non IP frames */
    SX_LAG_HASH_VID_IP = 7,                 /**< Vlan ID accounted in flow hash for IPv4 and IPv6 frames */
    SX_LAG_HASH_VID_NON_IP = 8,             /**< Vlan ID accounted in flow hash for non IP frames */
    SX_LAG_HASH_S_IP = 9,                   /**< Source IP accounted in flow hash */
    SX_LAG_HASH_D_IP = 10,                  /**< Destination IP accounted in flow hash  */
    SX_LAG_HASH_L4_SPORT = 11,              /**< TCP/UDP source port accounted in flow hash  */
    SX_LAG_HASH_L4_DPORT = 12,              /**< TCP/UDP destination port accounted in flow hash  */
    SX_LAG_HASH_L3_PROTO = 13,              /**< IPv4 next protocol / IPv6 next header accounted in flow hash  */
    SX_LAG_HASH_IPV6_FLOW_LABEL = 14,       /**< IPv6 flow label accounted in flow hash  */
    SX_LAG_HASH_SID = 15,                   /**< FCoE source ID accounted in flow hash */
    SX_LAG_HASH_DID = 16,                   /**< FCoE destination ID accounted in flow hash */
    SX_LAG_HASH_OXID = 17,                  /**< FCoE originator exchange ID accounted in flow hash */
    SX_LAG_HASH_D_QP = 19                   /**< Destination QP number accounted in flow hash */
} sx_lag_hash_bit_number_t;

static __attribute__((__used__)) const char* sx_default_hash_lag_str[] = {
    "INGRESS_PORT",           /**< Igress port accounted in flow hash */
    "SMAC_IP",                /**< Source MAC accounted in flow hash for IPv4 and IPv6 frames */
    "SMAC_NON_IP",            /**< Source MAC accounted in flow hash for non IP frames */
    "DMAC_IP",                /**< Destination MAC accounted in flow hash for IPv4 and IPv6 frames */
    "DMAC_NON_IP",            /**< Destination MAC accounted in flow hash for non IP frames */
    "ETHER_IP",               /**< Ethertype accounted in flow hash for IPv4 and IPv6 frames */
    "ETHER_NON_IP",           /**< Ethertype accounted in flow hash for non IP frames */
    "VID_IP",                 /**< Vlan ID accounted in flow hash for IPv4 and IPv6 frames */
    "VID_NON_IP",             /**< Vlan ID accounted in flow hash for non IP frames */
    "SRC_IP",                 /**< Source IP accounted in flow hash */
    "DST_IP",                 /**< Destination IP accounted in flow hash  */
    "L4_SRC_PORT",            /**< TCP/UDP source port accounted in flow hash  */
    "L4_DST_PORT",            /**< TCP/UDP destination port accounted in flow hash  */
    "L3_PROTOCOL",            /**< IPv4 next protocol / IPv6 next header accounted in flow hash  */
    "IPV6_FLOW_LABEL",        /**< IPv6 flow label accounted in flow hash  */
    "FCoE SRC ID",            /**< FCoE source ID accounted in flow hash */
    "FCoE DEST ID",           /**< FCoE destination ID accounted in flow hash */
    "FCoE ORIG EX ID",        /**< FCoE originator exchange ID accounted in flow hash */
    "DESTINATION_QP",         /**< Destination QP number accounted in flow hash */
};

#define SX_DEFAULT_LAG_HASH_STR_LEN (sizeof(sx_default_hash_lag_str) / sizeof(char*))
#define SX_DEFAULT_LAG_HASH_STR(index)                      \
    (SX_CHECK_MAX(index, SX_DEFAULT_LAG_HASH_STR_LEN - 1) ? \
     sx_default_hash_lag_str[index] : "UNKNOWN")

/**
 * sx_lag_hash_t is a bit map of required flow parameters
 * the user sets the bits indicating flow hash parameters
 * according to  sx_lag_hash_bit_number_t enum
 */
typedef uint32_t sx_lag_hash_t;

/**
 * sx_lag_seed_t is a uint32_t type. it is used for LAG flow
 * hash parameters
 */
typedef uint32_t sx_lag_seed_t;

typedef enum {
    SX_LAG_HASH_TYPE_FIRST = 0,
    SX_LAG_HASH_TYPE_CRC = 0,           /**< hash type is CRC */
    SX_LAG_HASH_TYPE_XOR = 1,           /**< hash type is XOR */
    SX_LAG_HASH_TYPE_LAST = SX_LAG_HASH_TYPE_XOR
} sx_lag_hash_type_t;

typedef struct sx_lag_hash_param {
    sx_lag_hash_type_t lag_hash_type;   /**< Hash type */
    sx_lag_hash_t      lag_hash;             /**< bit field - sx_lag_hash_bit_number_t */
    sx_lag_seed_t      lag_seed;             /**< LAG seed */
} sx_lag_hash_param_t;

/**
 * sx_lag_params_t structure is used to store initialization parameters of
 * LAG Library.
 */
typedef struct sx_lag_params {
    uint32_t      max_ports_per_lag; /**< Maximum ports in a LAG */
    sx_lag_hash_t default_lag_hash; /**< LAG Hash */
} sx_lag_params_t;

typedef struct sx_lag_fine_grain_member {
    sx_port_log_id_t log_port;     /**< logical Port ID */
    uint32_t         weight;       /**< the weight of the port */
} sx_lag_fine_grain_member_t;

typedef struct sx_lag_fine_grain_params {
    uint32_t resolution;             /**< resolution of the distribution list.
                                      * possible values: 512, 1024, 2048, 4096 */
} sx_lag_fine_grain_params_t;


/**
 * sx_ladb_port_data_t structure is used to store LAG port's data
 */
typedef struct {
    sx_port_id_t        port;    /** Lag port */
    sx_collector_mode_t collector_state;    /** collector state */
} sx_ladb_port_data_t;

/**
 * sx_ladb_port_indices_t structure is used to store LAG port's indices DB
 */
typedef struct {
    cl_plock_t          p_lock;
    uint32_t            max_lag_ports;
    uint32_t            max_lid;
    sx_ladb_port_data_t lag_ports[0];    /** Place keeper, actual size determined on init*/
} sx_ladb_port_indices_t;

#endif /* __SX_LAG_H__ */
