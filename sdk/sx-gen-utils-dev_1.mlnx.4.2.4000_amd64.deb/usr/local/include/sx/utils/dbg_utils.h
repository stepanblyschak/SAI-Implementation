/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef     __DBG_UTILS_H__
#define     __DBG_UTILS_H__

#include <complib/cl_types.h>
#include <stdio.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_DATA_STR_WIDTH     40
#define DBG_UTILS_DATA_STR_PRECISION 65
#define DBG_UTILS_VAL_STR_PRECISION  65

#define DBG_UTILS_SCRN_WIDTH_MAX 150
#define DBG_UTILS_NODES_MAX      129

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum dbg_utils_param_type {
    PARAM_UINT8_E,
    PARAM_UINT16_E,
    PARAM_UINT32_E,
    PARAM_UINT64_E,
    PARAM_HEX_E,
    PARAM_STRING_E,
    PARAM_EXT_STRING_E,
    PARAM_BOOL_E,
    PARAM_MAC_ADDR_E,
    PARAM_IPV4_E,
    PARAM_IPV4_MASK_E,
    PARAM_IPV6_E,
    PARAM_FC_ADDR_E,
    PARAM_DOUBLE_E,
    PARAM_INT_E,
    PARAM_HEX16_E,
    PARAM_LAST_E
} dbg_utils_param_type_e;

typedef struct dbg_utils_table_columns {
    char                 * name;
    int                    width;
    dbg_utils_param_type_e type;
    const void            *data;
} dbg_utils_table_columns_t;

typedef struct dbg_utils_tree_node {
    uint32_t left_child;
    uint32_t right_child;
} dbg_utils_tree_node_t;

typedef struct dbg_utils_tree {
    uint32_t              root;
    uint32_t              node_count;
    dbg_utils_tree_node_t nodes[DBG_UTILS_NODES_MAX];
} dbg_utils_tree_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

void dbg_utils_print(FILE *stream, const char *fmt, ...) __attribute__ ((format(printf, 2, 3)));

/*
 * prints field name and value in a fixed alignment
 */
void dbg_utils_print_field(FILE                  *stream,
                           const char            *name,
                           const void            *data,
                           dbg_utils_param_type_e type);

/*
 * prints module header
 */
void dbg_utils_print_module_header(FILE       *stream,
                                   const char *module_name);

/*
 * prints table headline
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 */
void dbg_utils_print_table_headline(FILE                      *stream,
                                    dbg_utils_table_columns_t *columns);
/*
 * prints table headline
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 */
void dbg_utils_print_table_data_line(FILE                      *stream,
                                     dbg_utils_table_columns_t *columns);


/*
 * prints counters group header with port ID info
 */
void dbg_utils_print_counters_group_header(FILE       *stream,
                                           const char *cntr_grp_name,
                                           uint32_t    port_id);
/*
 * prints counter name and value
 * calls print field function
 */
void dbg_utils_print_counter(FILE       *stream,
                             const char *cntr_name,
                             uint64_t    cntr_value);

/*
 * prints general purpose header
 * should be used in all cases excluding module and counters group headers.
 */
void dbg_utils_print_general_header(FILE *stream,
                                    const char *headline_fmt, ...) __attribute__ ((format(printf, 2, 3)));

/*
 * prints secondary header
 * provides headers hierarchy.
 */
void dbg_utils_print_secondary_header(FILE *stream,
                                      const char *headline, ...) __attribute__ ((format(printf, 2, 3)));

void dbg_utils_draw_binary_tree(FILE                   *stream,
                                const dbg_utils_tree_t* tree);

/*
 * prints current time stamp
 */
void dbg_utils_print_time_stamp(FILE *stream);

#endif /* __DBG_UTILS__ */
