/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __APPLIBS_ETHL3_ECMP_ALLOCATOR_H__
#define __APPLIBS_ETHL3_ECMP_ALLOCATOR_H__

#include <complib/cl_mem.h>
#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_qmap.h>
#include "bin_allocator.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


/** Forward declaration for an internal data type */
struct ecmp_block_data;

/**
 * This struct defines all ECMP-related information which is kept by the ECMP allocator for each neighbor
 * The user of this module may keep a member of this type in the object that represents the neighbor
 */
typedef struct neigh_ecmp_data {
    /** The set of all ECMP entries which include this neighbor */
    cl_qmap_t ecmps;
} neigh_ecmp_data_t;

/**  This struct defines an entry in the map neigh_ecmp_data_t.ecmps */
typedef struct neigh_ecmp_entry {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    const neigh_ecmp_data_t* neigh;
    struct ecmp_block_data * entry;
} neigh_ecmp_entry_t;

/**
 * Callback which is defined by the user of this module.
 * Sets an adjacency entry in firmware
 * @param index The index of the adjacency entry to set
 * @param neigh A pointer to the neighbor which is to be written at the index
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other error value otherwise
 */
typedef sx_utils_status_t (*adjacency_set_t)(uint32_t index, const neigh_ecmp_data_t* neigh);

typedef sx_utils_status_t (*ecmp_enlarge_t)(bin_database_t database);

/**
 * This struct defines the parameters for the ECMP allocator
 */
typedef struct ecmp_params {
    /** Returns the allocated adjacency table */
    bin_database_t* adjacency_table;
    /** Specifies a callback for calculating the cost of relocations */
    bin_relocation_cost_t router_relocation_cost;
    /** Specifies a callback for performing block movement */
    bin_relocation_t router_block_moved;
    /** Specifies a callback for writing an adjacency entry */
    adjacency_set_t adjacency_set;
    /** Specifies a callback for enlarging the bin_allocator table */
    ecmp_enlarge_t enlarge_cb;
    /** Minimum index into the adjacency table */
    uint32_t arp_id_min;
    /** One more than the maximum index into the adjacency table */
    uint32_t arp_id_max;
} ecmp_params_t;


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize the ECMP allocator module, and a bin allocator for the adjacency-table
 * @param params A structure that contains all parameters for the ECMP allocator
 * @return SX_UTILS_STATUS_SUCCESS if successful, or other SX_UTILS_STATUS_ value otherwise
 */
sx_utils_status_t ecmp_allocator_init(ecmp_params_t* params);

/**
 * Deinitialize and free resources of this module
 * Note: Also deinitializes the adjacency table bin_allocator
 * @return SX_UTILS_STATUS_SUCCESS if successful, or other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_allocator_deinit();

/**
 * Initialize the neighbor-specific ECMP data structure
 * @param ecmp_data A neighbor-specific ECMP data structure to initialize
 */
void ecmp_data_init(neigh_ecmp_data_t* ecmp_data);

/**
 * Get an ECMP block for use with a specified set of next-hops
 * Note: For every successful call to this function, the caller is expected to call ecmp_free_block() when the returned block is not needed anymore
 *
 * @param neigh_arr Array of pointers to neighbor entries which constitues the set of next-hops
 * @param next_hop_num The amount of next hop pointers in neigh_arr
 * @param block Returns a block which may be used for this set of next-hops
 * @return SX_UTILS_STATUS_SUCCESS if successful and exact (either pre-existing exact match, or newly-allocated)
 *         SX_UTILS_STATUS_PARTIALLY_COMPLETE if successful and partial (best-match)
 *         SX_UTILS_STATUS_ENTRY_NOT_FOUND if there is no match (single-path fallback)
 *         or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_add(neigh_ecmp_data_t **neigh_arr,
                           uint32_t            next_hop_num,
                           bin_block_t       * block);

/**
 * Find an ECMP block which is an existing exact match for use with a specified set of next-hops
 * Note: For every successful call to this function, the caller is expected to call ecmp_free_block() when the returned block is not needed anymore
 * Note: Callers should consider using ecmp_add() instead
 * @param neigh_arr Array of pointers to neighbor entries which constitues the set of next-hops
 * @param next_hop_num The amount of next hop pointers in neigh_arr
 * @param block Returns a block which may be used for this set of next-hops
 * @return SX_UTILS_STATUS_SUCCESS if successful
 *         SX_UTILS_STATUS_ENTRY_NOT_FOUND if match was not found
 *         or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_find_exact_match(neigh_ecmp_data_t **neigh_arr,
                                        uint32_t            next_hop_num,
                                        bin_block_t       * block);

/**
 * Aloocate a new ECMP block for use with a specified set of next-hops
 * This function assumes that an exact match does not already exist
 * If successful, the returned block matches the specified set of next-hops exactly
 * Note: For every successful call to this function, the caller is expected to call ecmp_free_block() when the returned block is not needed anymore
 * Note: Callers should consider using ecmp_add() instead
 * @param neigh_arr Array of pointers to neighbor entries which constitues the set of next-hops
 * @param next_hop_num The amount of next hop pointers in neigh_arr
 * @param block Returns a block which can be used for this set of next-hops
 * @return SX_UTILS_STATUS_SUCCESS if successful
 *         SX_UTILS_STATUS_NO_RESOURCES if not enough space in the adjacency table
 *         or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_allocate_block(neigh_ecmp_data_t **neigh_arr,
                                      uint32_t            next_hop_num,
                                      bin_block_t       * block);

/**
 * Find the best existing ECMP block for use with a specified set of next-hops
 * This function assumes that an exact match does not already exist
 * If successful, the returned block is a subset, of at least two hops, of the specified set of next-hops
 * Note: For every successful call to this function, the caller is expected to call ecmp_free_block() when the returned block is not needed anymore
 * Note: Callers should consider using ecmp_add() instead
 * @param neigh_arr Array of pointers to neighbor entries which constitues the set of next-hops
 * @param next_hop_num The amount of next hop pointers in neigh_arr
 * @param block Returns a block which can be used for this set of next-hops
 * @return SX_UTILS_STATUS_SUCCESS if successful
 *         SX_UTILS_STATUS_ENTRY_NOT_FOUND if no match was found
 *         or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_find_best_match(neigh_ecmp_data_t **neigh_arr,
                                       uint32_t            next_hop_num,
                                       bin_block_t       * block);

/**
 * Free a previously allocated block
 * This function should be called once for every successful call to any one of the four allocation functions:
 * * ecmp_add
 * * ecmp_find_exact_match
 * * ecmp_allocate_block
 * * ecmp_find_best_match
 * Note: The block object is not re-initialized. The caller is expected to perform any required reusability cleanup.
 * @param block A block which was returned from one of the allocation functions
 * @return SX_UTILS_STATUS_SUCCESS if successful, or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_free_block(bin_block_t* block);

/**
 * Retrieve the set of next-hops which is used in a previously-allocated block
 * @param block A block which was returned from one of the allocation functions
 * @param neigh_arr Returns an array of pointers to the set of next-hops.
 *        In order to retrieve the full list of active next-hops, the array needs
 *        to contain at least SX_ROUTER_NEXT_HOP_MAX pointers
 *        This parameter may be NULL if only the amount of next-hops is requested
 * @param next_hop_num Specifies the amount of pointers available in neigh_arr,
 *        and returns the amount of next hop pointers stored in neigh_arr
 * @param block Specifies the block for which the set of next-hops is returned
 * @return SX_UTILS_STATUS_SUCCESS if successful
 *         or any other SX_UTILS_STATUS_* value otherwise
 */
sx_utils_status_t ecmp_get_block_neighbors(neigh_ecmp_data_t **neigh_arr,
                                           uint32_t          * next_hop_num,
                                           bin_block_t       * block);

#ifdef UNITTESTS
/**
 * This structure defines all the ECMP internal accounting information
 */
typedef struct {
    /** Maximum number of distinct ECMP blocks used */
    uint32_t max_distinct_blocks;
    /** Number of RATR-set operations used for ECMP blocks */
    uint32_t ratr_set_count;
    /** Number of times an ECMP block was moved */
    uint32_t block_movement_count;
    /** Number of times an exact match was found */
    uint32_t exact_hit_count;
    /** Number of times a best-match was found */
    uint32_t best_match_count;
    /** Number of times no match was found (and thus a single-path route would be used) */
    uint32_t single_path_match_count;
} ecmp_accounting_t;

/**
 * Retrieves accounting information from the ECMP allocator
 * @param accounting Pointer to a structure to be filled with accounting information
 */
void ecmp_get_accounting(ecmp_accounting_t* accounting);

/**
 * Dump the current state of the ECMP allocator
 */
void ecmp_dump();

#endif /* ifdef UNITTESTS */

#endif /* __APPLIBS_ETHL3_ECMP_ALLOCATOR_H__ */
