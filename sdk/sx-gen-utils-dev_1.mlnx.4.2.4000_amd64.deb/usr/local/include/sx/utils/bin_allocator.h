/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __UTILS_BIN_ALLOCATOR_H__
#define __UTILS_BIN_ALLOCATOR_H__

/**
 * Bin allocation module responsible for allocating entries
 * The module has the following operations:
 *  - Init/Deinit.
 *  - Allocation/free
 *  - Background defrag process
 */

#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


typedef struct {
    /* @param size number of entries per block */
    uint32_t size;
    /* @param index Internal index into a block
     * Internal: The index is divided into 2 16 bits parameters. The higher 16 bit is a page index. The lower 16bit is index inside the page
     * @see bin_get_slot_index
     */
    uint32_t index;
} bin_block_t;

typedef enum {
    DEFRAG_ENABLE_DEMIX = 1 << 0,
        DEFRAG_ENABLE_DEFRAG = 1 << 1,
        DEFRAG_ENABLE_PAGE_DEFRAG = 1 << 2,

        DEFRAG_ENABLE_ALL = DEFRAG_ENABLE_DEMIX | DEFRAG_ENABLE_DEFRAG | DEFRAG_ENABLE_PAGE_DEFRAG
} bin_defrag_features_e;
typedef unsigned int bin_defrag_features_t;

typedef void* bin_database_t;

#define RELOCATION_THRESHOLD_ALL (0xFFFFFFFF)

#define NUM_OF_ENTRIES_PER_PAGE_SHIFT (6)   /* 64 pages */
#define NUM_OF_ENTRIES_PER_PAGE       (1 << NUM_OF_ENTRIES_PER_PAGE_SHIFT) /* 64 */

/**
 * A callback prototype. For each relocation of 2 blocks, as a result of de-mix or de-frag,
 * this function is being invoked
 */
typedef sx_utils_status_t (*bin_relocation_t)(bin_database_t database,
                                              bin_block_t  * old_block,
                                              bin_block_t  * new_block,
                                              boolean_t      enable_ecmp_move);

/**
 * Return the cost of move operation per block
 */
typedef uint32_t (*bin_relocation_cost_t)(bin_database_t database,
                                          bin_block_t  * old_block);
/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Set block into invalid value
 */
void bin_block_init(bin_block_t* block);

/**
 * Compare two blocks
 */
int bin_block_compare(const bin_block_t* block1, const bin_block_t* block2);

/**
 * @return TRUE if block is in valid range, FALSE otherwise
 */
boolean_t bin_is_block_valid(const bin_block_t* block);

/**
 * From a block calculate the first slot index
 */
sx_utils_status_t bin_get_slot_index(bin_database_t database, const bin_block_t* block, uint32_t* index);

/**
 * Initialize bin datastructure
 *
 * @param database        [out] Will be filled with the datastructure handle
 * @param start_index     [in] Start index into the table
 * @param end_index       [in] End index into the table
 * @param relocation_cost [in] A callback function for relocation cost request
 * @param relocation      [in] A callback function for relocation request
 * @param relocation_threshold  [in] The maximum number of relocation allowed per operation. If the valie is
 *                                   RELOCATION_THRESHOLD_ALL, then every rekocation will be moved.
 *
 * @note The size of the table is limited in 16 bit enteries (So end_index-start_index < 65536 indexes)
 * @note Also the table size must be a multiplcation of 64
 */
sx_utils_status_t bin_init(bin_database_t      * database,
                           uint32_t              start_index,
                           uint32_t              end_index,
                           bin_relocation_cost_t relocation_cost,
                           bin_relocation_t      relocation,
                           uint32_t              relocation_threshold);

/**
 * Free all allocated resources. Assert if some of the entries/pages wheren't free yet
 */
sx_utils_status_t bin_deinit(bin_database_t database);

/**
 * Retrieves the amount of free pages in the table.
 * If this function returns nonzero, then it is safe to resize the table to remove that number of free pages
 * @param database [in] A handle to a bin allocator table
 */
uint32_t bin_get_free_page_count(bin_database_t database);

/**
 * Resize a bin allocator's table
 * @param database [in] A handle to a bin allocator table
 * @param new_end_index [in] A new end index into the table
 */
sx_utils_status_t bin_resize(bin_database_t database, uint32_t new_end_index);

/**
 * Allocate a 'index.size' continuous entries at a table
 *
 * @param index.size [in] Specifies a number of continuous entries
 * @param index.index [out] returns the location index inside the table
 *
 * @return SX_UTILS_STATUS_SUCCESS if memory allocation completed successfuly
 * @return SX_UTILS_STATUS_NO_RESOURCES if there was problem with allocation
 */
sx_utils_status_t bin_allocate(bin_database_t database,
                               bin_block_t  * index);

/**
 * Free a 'index.size' continuous entries from a page/offset located at index.index
 *
 * @param index.size [in] Specifies a number of continuous entries at the table. This must be exactly the same
 *                        paramters as was given to bin_allocate, other memory allocation will be triggered
 * @param index.index [in] The block index to free
 *
 * @note The bin module doesn't remember the allocation sizes. When DEBUG is being set to the compilation a debug array
 *       will remember the allocation sizes, this is for debugging purposes only
 */
sx_utils_status_t bin_free(bin_database_t database, bin_block_t* index);

/**
 * Determine the number of bins
 *
 * @return the number of bins
 */
uint32_t bin_get_bin_count();

/**
 * @database [in] The database to works with
 * @bin      [in] A bin location from 0..bin_get_bin_count()-1
 * @number_of_full_pages [out] will be filled with the number_of_full_pages
 * @number_of_not_full_pages [out] will be filled with the number_of_not_full_pages
 * @number_of_mixed_full_pages [out] will be filled with the number_of_mixed_full_pages
 * @number_of_mixed_not_full_pages [out] will be filled with the number_of_mixed_not_full_pages
 *
 * @return SX_UTILS_STATUS_PARAM_ERROR if database is corrupted
 */
sx_utils_status_t bin_get_statistics(bin_database_t database, uint32_t bin,
                                     unsigned int* number_of_full_pages,
                                     unsigned int* number_of_not_full_pages,
                                     unsigned int* number_of_mixed_full_pages,
                                     unsigned int* number_of_mixed_not_full_pages);

/**
 * Start a defrag algorithm. The derag process is executed on a bin and has a difficult parameter as indication about the amount
 * of effort and operation needed to be done. Infinite stand for "Try everything until the bin is fully defrag"
 *
 * @database [in] The database to works with
 * @bin      [in] A bin location from 0..bin_get_bin_count()-1 to defrag
 *
 * @return SX_UTILS_STATUS_SUCESS if there is a relocation.
 * @note Please see get_bin_defrag_counter to review
 */
sx_utils_status_t bin_defrag(bin_database_t database, uint32_t bin);

/**
 * Change which features are allowed during defrag process.
 *
 * @database [in] The database to works with
 * @features [in] @see bin_defrag_features_e
 */
sx_utils_status_t bin_defrag_set_features(bin_database_t database, bin_defrag_features_t features);

/**
 * @database [in] The database to works with
 * @old_counter [out] will be filled with the last counter before a call to bin_defrag
 * @new_counter [out] will be filled with the current counter after a call to bin_defrag
 * @note: A call to bin_defrag DOESN'T clear these counters, this is why there are 2 counters
 *
 * @return SX_UTILS_STATUS_PARAM_ERROR if database is corrupted
 */
sx_utils_status_t bin_get_defrag_counter(bin_database_t database,
                                         unsigned int * old_counter,
                                         unsigned int * new_counter);

/**
 * Change the relocation threshold
 */
sx_utils_status_t bin_set_relocation_threshold(bin_database_t database, unsigned int relocation_threshold);

#ifdef UNITTESTS
/**
 * Dump the entrie database (if bin == 7)
 * Dump a bin (if bin = 0..6)
 */
void bin_allocator_dump(bin_database_t database, uint32_t bin);
#endif

#endif /* __UTILS_BIN_ALLOCATOR_H__ */
