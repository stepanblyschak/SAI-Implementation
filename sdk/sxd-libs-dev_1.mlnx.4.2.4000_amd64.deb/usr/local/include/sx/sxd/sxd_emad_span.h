/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SPAN_H__
#define __SXD_EMAD_SPAN_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_emad_span_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD MSTP MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_span_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                               IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_mpat_set(sxd_emad_mpat_data_t         *mpat_data_arr,
                               uint32_t                      mpat_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_mpat_get(sxd_emad_mpat_data_t         *mpat_data_arr,
                               uint32_t                      mpat_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_mpar_set(sxd_emad_mpar_data_t         *mpar_data_arr,
                               uint32_t                      mpar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_mpar_get(sxd_emad_mpar_data_t         *mpar_data_arr,
                               uint32_t                      mpar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sbib_set(sxd_emad_sbib_data_t         *sbib_data_arr,
                               uint32_t                      sbib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sbib_get(sxd_emad_sbib_data_t         *sbib_data_arr,
                               uint32_t                      sbib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


#endif /* __SXD_EMAD_MSTP_H__ */
