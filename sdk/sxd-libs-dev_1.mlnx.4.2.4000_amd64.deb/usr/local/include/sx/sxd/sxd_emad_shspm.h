/*
 * Copyright (C) Mellanox Technologies, Ltd. 2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SHSPM_H__
#define __SXD_EMAD_SHSPM_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_shspm_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD SHSPM MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_shspm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function sets RALTA register data.
 *
 * @param[in] ralta_data_arr - RALTA data array.
 * @param[in] ralta_data_num - RALTA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralta_set(sxd_emad_ralta_data_t        *ralta_data_arr,
                                uint32_t                      ralta_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RALTA register data.
 *
 * @param[in] lta_data_arr - RALTA data array.
 * @param[in] lta_data_num - RALTA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralta_get(sxd_emad_ralta_data_t        *ralta_data_arr,
                                uint32_t                      ralta_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RALST register data.
 *
 * @param[in] ralst_data_arr - RALST data array.
 * @param[in] ralst_data_num - RALST data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralst_set(sxd_emad_ralst_data_t        *ralst_data_arr,
                                uint32_t                      ralst_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RALST register data.
 *
 * @param[in] ralst_data_arr - RALST data array.
 * @param[in] ralst_data_num - RALST data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralst_get(sxd_emad_ralst_data_t        *ralst_data_arr,
                                uint32_t                      ralst_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RALTB register data.
 *
 * @param[in] raltb_data_arr - RALTB data array.
 * @param[in] raltb_data_num - RALTB data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_raltb_set(sxd_emad_raltb_data_t        *raltb_data_arr,
                                uint32_t                      raltb_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RALTB register data.
 *
 * @param[in] raltb_data_arr - RALTB data array.
 * @param[in] raltb_data_num - RALTB data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_raltb_get(sxd_emad_raltb_data_t        *raltb_data_arr,
                                uint32_t                      raltb_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RALUE register data.
 *
 * @param[in] ralue_data_arr - RALUE data array.
 * @param[in] ralue_data_num - RALUE data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralue_set(sxd_emad_ralue_data_t        *ralue_data_arr,
                                uint32_t                      ralue_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RALUE register data.
 *
 * @param[in] ralue_data_arr - RALUE data array.
 * @param[in] ralue_data_num - RALUE data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralue_get(sxd_emad_ralue_data_t        *ralue_data_arr,
                                uint32_t                      ralue_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RALEU register data.
 *
 * @param[in] raleu_data_arr - RALEU data array.
 * @param[in] raleu_data_num - RALEU data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_raleu_set(sxd_emad_raleu_data_t        *raleu_data_arr,
                                uint32_t                      raleu_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RALBU register data.
 *
 * @param[in] ralbu_data_arr - RALBU data array.
 * @param[in] ralbu_data_num - RALBU data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ralbu_set(sxd_emad_ralbu_data_t        *ralbu_data_arr,
                                uint32_t                      ralbu_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

#endif /* __SXD_EMAD_SHSPM_H__ */
