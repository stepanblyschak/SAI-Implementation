/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_STATUS_H__
#define __SXD_EMAD_STATUS_H__

#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_status_t
 * Enumerated type - Used to provide function return values.
 */
typedef enum sxd_emad_status {
    SXD_EMAD_STATUS_SUCCESS = 0,            /**< Success */
    SXD_EMAD_STATUS_DEVICE_IS_BUSY,         /**< Device Busy Error */
    SXD_EMAD_STATUS_VERSION_NOT_SUPPORTED,  /**< Version Not Suported */
    SXD_EMAD_STATUS_UNKNOWN_TLV,            /**< UnKnown TLV */
    SXD_EMAD_STATUS_REGISTER_NOT_SUPPORTED, /**< Register Not Supported */
    SXD_EMAD_STATUS_CLASS_NOT_SUPPORTED,    /**< Class Not Supported */
    SXD_EMAD_STATUS_METHOD_NOT_SUPPORTED,   /**< Methhod Not Supported */
    SXD_EMAD_STATUS_BAD_PARAMETER,          /**< Bed Parameter Error */
    SXD_EMAD_STATUS_RESOURCE_NOT_AVALIABLE, /**< Resource Not Available */
    SXD_EMAD_STATUS_MESSAGE_RECEIPT_ACK,    /**< Message Receipt ACK */

    SXD_EMAD_STATUS_MIN = SXD_EMAD_STATUS_SUCCESS,              /**< Min ENUM value */
    SXD_EMAD_STATUS_MAX = SXD_EMAD_STATUS_MESSAGE_RECEIPT_ACK,  /**< Max ENUM value */
} sxd_emad_status_t;

/************************************************
 *  Global variables
 ***********************************************/

static __attribute__((__used__)) const char *sxd_emad_status2str_arr[] = {
    /*SXD_EMAD_STATUS_SUCCESS*/
    "SUCCESS",
    /*SXD_EMAD_STATUS_DEVICE_IS_BUSY*/
    "DEVICE IS BUSY",
    /*SXD_EMAD_STATUS_VERSION_NOT_SUPPORTED*/
    "VERSION NOT SUPPORTED",
    /*SXD_EMAD_STATUS_UNKNOWN_TLV*/
    "UNKNOWN TLV",
    /*SXD_EMAD_STATUS_REGISTER_NOT_SUPPORTED*/
    "REGISTER NOT SUPPORTED",
    /*SXD_EMAD_STATUS_CLASS_NOT_SUPPORTED*/
    "CLASS NOT SUPPORTED",
    /*SXD_EMAD_STATUS_METHOD_NOT_SUPPORTED*/
    "METHOD NOT SUPPORTED",
    /*SXD_EMAD_STATUS_BAD_PARAMETER*/
    "BAD PARAMETER",
    /*SXD_EMAD_STATUS_RESOURCE_NOT_AVALIABLE*/
    "RESOURCE NOT AVALIABLE",
    /*SXD_EMAD_STATUS_MESSAGE_RECEIPT_ACK*/
    "MESSAGE RECEIPT ACK",
};


/************************************************
 *  Macros
 ***********************************************/

/**
 * SXD_EMAD_STATUS_CHECK_RANGE:
 * Check the validity of the supplied STATUS
 * STATUS - Status to be checked
 */
#define SXD_EMAD_STATUS_CHECK_RANGE(STATUS) SXD_CHECK_MAX(STATUS, SXD_EMAD_STATUS_MAX)

/**
 * SXD_EMAD_STATUS_MSG:
 *  Check the validity of the supplied STATUS & return string
 *  STATUS - Status to be checked
 */
#define SXD_EMAD_STATUS_MSG(STATUS)                                         \
    SXD_EMAD_STATUS_CHECK_RANGE(STATUS) ? sxd_emad_status2str_arr[STATUS] : \
    "Unknown return code"


/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_STATUS_H__ */
