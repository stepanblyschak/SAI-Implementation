/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_LAG_DATA_H__
#define __SXD_EMAD_LAG_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_lag.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_sfdt_data_t structure is used to store SFDT
 * register data.
 */
typedef struct sxd_emad_sfdt_data {
    sxd_emad_common_data_t common;
    struct ku_sfdt_reg    *reg_data;
} sxd_emad_sfdt_data_t;

/**
 * sxd_emad_sldr_operation_e enumerated type is used to note the
 * SLDR operation.
 */
typedef enum sxd_emad_sldr_operation {
    SXD_EMAD_SLDR_OPERATION_CREATE_LAG_E = 0,
    SXD_EMAD_SLDR_OPERATION_DESTROY_LAG_E = 1,
    SXD_EMAD_SLDR_OPERATION_ADD_PORT_LIST_E = 2,
    SXD_EMAD_SLDR_OPERATION_DEL_PORT_LIST_E = 3,
    SXD_EMAD_SLDR_OPERATION_LAG_REDIRECT_E = 4,
    SXD_EMAD_SLDR_OPERATION_FINE_GRAIN_LAG_ENABLE = 5,
    SXD_EMAD_SLDR_OPERATION_FINE_GRAIN_LAG_DISABLE = 6,
} sxd_emad_sldr_operation_e;

/**
 * sxd_emad_sldr_data_t structure is used to store SLDR
 * register data.
 */
typedef struct sxd_emad_sldr_data {
    sxd_emad_common_data_t common;
    struct ku_sldr_reg    *reg_data;
} sxd_emad_sldr_data_t;

/**
 * sxd_emad_lag_hash_type_e enumarated type is used to store LAG
 * Hash Type.
 */
typedef enum sxd_emad_lag_hash_type {
    SXD_EMAD_LAG_HASH_TYPE_XOR_E = 0,
    SXD_EMAD_LAG_HASH_TYPE_CRC_E = 1,
} sxd_emad_lag_hash_type_e;

/**
 * sxd_emad_lag_hash_e enumarated type is used to store LAG
 * Hashing Configuration.
 */
typedef enum sxd_emad_lag_hash {
    SXD_EMAD_LAG_HASH_INGRESS_PORT_E = (1 << 0),
    SXD_EMAD_LAG_HASH_SMAC_IP_E = (1 << 1),
    SXD_EMAD_LAG_HASH_SMAC_NON_IP_E = (1 << 2),
    SXD_EMAD_LAG_HASH_DMAC_IP_E = (1 << 3),
    SXD_EMAD_LAG_HASH_DMAC_NON_IP_E = (1 << 4),
    SXD_EMAD_LAG_HASH_ETHERTYPE_IP_E = (1 << 5),
    SXD_EMAD_LAG_HASH_ETHERTYPE_NON_IP_E = (1 << 6),
    SXD_EMAD_LAG_HASH_VID_IP_E = (1 << 7),
    SXD_EMAD_LAG_HASH_VID_NON_IP_E = (1 << 8),
    SXD_EMAD_LAG_HASH_SRC_IP_E = (1 << 9),
    SXD_EMAD_LAG_HASH_DST_IP_E = (1 << 10),
    SXD_EMAD_LAG_HASH_TCP_UDP_SRC_PORT_E = (1 << 11),
    SXD_EMAD_LAG_HASH_TCP_UDP_DST_PORT_E = (1 << 12),
    SXD_EMAD_LAG_HASH_IPV4_PROT_IPV6_NEXT_HEADER_E = (1 << 13),
    SXD_EMAD_LAG_HASH_IPV6_FLOW_LABEL_E = (1 << 14),
    SXD_EMAD_LAG_HASH_SID_E = (1 << 15),
    SXD_EMAD_LAG_HASH_DID_E = (1 << 16),
    SXD_EMAD_LAG_HASH_OXID_E = (1 << 17),
    SXD_EMAD_LAG_HASH_TCAM_E = (1 << 18),
    SXD_EMAD_LAG_HASH_DST_QPN_E = (1 << 19),
} sxd_emad_lag_hash_e;

/**
 * sxd_emad_slcr_data_t structure is used to store SLCR
 * register data.
 */
typedef struct sxd_emad_slcr_data {
    sxd_emad_common_data_t common;
    struct ku_slcr_reg    *reg_data;
} sxd_emad_slcr_data_t;

/**
 * sxd_emad_slcor_collector_e enumerated type is used to note
 * the SLCOR collector configuration.
 */
typedef enum sxd_emad_slcor_collector {
    SXD_EMAD_SLDR_COLLECTOR_ADD_PORT_E = 0,
    SXD_EMAD_SLDR_COLLECTOR_ENABLE_E = 1,
    SXD_EMAD_SLDR_COLLECTOR_DISABLE_E = 2,
    SXD_EMAD_SLDR_COLLECTOR_REMOVE_PORT_E = 3,
} sxd_emad_slcor_collector_e;

/**
 * sxd_emad_slcor_data_t structure is used to store SLCOR
 * register data.
 */
typedef struct sxd_emad_slcor_data {
    sxd_emad_common_data_t common;
    struct ku_slcor_reg   *reg_data;
} sxd_emad_slcor_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_LAG_DATA_H__ */
