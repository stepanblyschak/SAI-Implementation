/*
 *                  - Mellanox Confidential and Proprietary -
 *
 *  Copyright (C) January 2010, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein, no portion of the information,
 *  including but not limited to object code and source code, may be reproduced,
 *  modified, distributed, republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "LICENSE.txt".
 *
 */

#ifndef __SXD_EMAD_PARSER_FLOW_COUNTER_H__
#define __SXD_EMAD_PARSER_FLOW_COUNTER_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_flow_counter_data.h>
#include <sx/sxd/sxd_emad_flow_counter_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of FLOW COUNTER PARSER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t emad_parser_flow_counter_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                          IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pfca_data - register data struct.
 * @param[out] pfca_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pfca(sxd_emad_pfca_data_t *pfca_data,
                                 sxd_emad_pfca_reg_t  *pfca_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pfca_data - register data struct.
 * @param[in] pfca_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pfca(sxd_emad_pfca_data_t *pfca_data,
                                   sxd_emad_pfca_reg_t  *pfca_reg);


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pfcnt_data - register data struct.
 * @param[out] pfcnt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pfcnt(sxd_emad_pfcnt_data_t *pfcnt_data,
                                  sxd_emad_pfcnt_reg_t  *pfcnt_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pfcnt_data - register data struct.
 * @param[in] pfcnt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pfcnt(sxd_emad_pfcnt_data_t *pfcnt_data,
                                    sxd_emad_pfcnt_reg_t  *pfcnt_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] mgpc_data - register data struct.
 * @param[out] mgpc_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_mgpc(sxd_emad_mgpc_data_t *mgpc_data,
                                 sxd_emad_mgpc_reg_t  *mgpc_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] mgpc_data - register data struct.
 * @param[in] mgpc_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_mgpc(sxd_emad_mgpc_data_t *mgpc_data,
                                   sxd_emad_mgpc_reg_t  *mgpc_reg);


#endif /* ifndef __SXD_EMAD_PARSER_FLOW_COUNTER_H__ */
