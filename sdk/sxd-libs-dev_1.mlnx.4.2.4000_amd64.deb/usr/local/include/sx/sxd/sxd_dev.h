/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_DEV_H__
#define __SXD_DEV_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define SXD_DEV_ID_MIN   (0x01)
#define SXD_DEV_ID_MAX   (0xFD)
#define SXD_DEV_ID_COUNT (SXD_DEV_ID_MAX - SXD_DEV_ID_MIN + 1)

#define SXD_DEV_ID_CHECK_RANGE(DEV_ID) \
    SXD_CHECK_RANGE(SXD_DEV_ID_MIN, DEV_ID, SXD_DEV_ID_MAX)

/************************************************
 *  Type definitions
 ***********************************************/


/**
 * Device ID.
 */
typedef uint8_t sxd_dev_id_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_DEV_H__ */
